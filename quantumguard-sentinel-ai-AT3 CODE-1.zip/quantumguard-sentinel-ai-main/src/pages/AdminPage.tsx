
import React from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ShieldAlert, Users, Database, AlertCircle } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const AdminPage: React.FC = () => {
  // Sample admin statistics
  const stats = [
    { 
      title: 'Quantum Security', 
      value: '96%', 
      description: 'Post-quantum cryptographic protection',
      icon: <ShieldAlert className="h-5 w-5 text-quantum-cyan" />
    },
    { 
      title: 'Active Analysts', 
      value: '12', 
      description: 'Currently monitoring transactions',
      icon: <Users className="h-5 w-5 text-quantum-cyan" /> 
    },
    { 
      title: 'Database Status', 
      value: 'Secure', 
      description: 'Last verified: 3 minutes ago',
      icon: <Database className="h-5 w-5 text-quantum-cyan" /> 
    },
    { 
      title: 'System Alerts', 
      value: '2', 
      description: 'Requires administrator review',
      icon: <AlertCircle className="h-5 w-5 text-quantum-cyan" /> 
    }
  ];

  // Sample system logs
  const systemLogs = [
    { timestamp: '2025-04-08 14:32:19', event: 'Database backup completed', level: 'info' },
    { timestamp: '2025-04-08 12:15:43', event: 'User authentication failure (3 attempts)', level: 'warning' },
    { timestamp: '2025-04-08 10:05:37', event: 'Model training completed - F1 Score: 0.94', level: 'info' },
    { timestamp: '2025-04-08 09:22:51', event: 'API rate limit exceeded for blockchain endpoint', level: 'error' },
    { timestamp: '2025-04-08 08:30:00', event: 'System startup - all services online', level: 'info' },
  ];

  return (
    <div className="min-h-screen bg-quantum-dark text-white">
      <Header />
      <main className="pt-16 px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <h2 className="text-2xl md:text-3xl font-bold text-white">Admin Console</h2>
            <p className="text-white/70">QuantumGuard AI System Administration</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <Card key={index} className="bg-white/5 border-white/10 hover:bg-white/10 transition-all">
                <CardHeader className="pb-2">
                  <CardTitle className="text-white/90 flex items-center text-lg">
                    {stat.icon}
                    <span className="ml-2">{stat.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold mb-1 text-quantum-cyan">{stat.value}</div>
                  <p className="text-sm text-white/70">{stat.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-lg p-6 mb-8">
            <h3 className="text-xl font-medium mb-4 flex items-center">
              <Database className="h-5 w-5 mr-2 text-quantum-cyan" />
              System Logs
            </h3>
            
            <Table>
              <TableHeader>
                <TableRow className="border-white/10">
                  <TableHead className="text-white/70">Timestamp</TableHead>
                  <TableHead className="text-white/70">Event</TableHead>
                  <TableHead className="text-white/70">Level</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {systemLogs.map((log, index) => (
                  <TableRow key={index} className="border-white/10">
                    <TableCell className="font-mono">{log.timestamp}</TableCell>
                    <TableCell>{log.event}</TableCell>
                    <TableCell>
                      {log.level === 'info' && (
                        <Badge className="bg-quantum-success/20 text-quantum-success">
                          Info
                        </Badge>
                      )}
                      {log.level === 'warning' && (
                        <Badge className="bg-quantum-warning/20 text-quantum-warning">
                          Warning
                        </Badge>
                      )}
                      {log.level === 'error' && (
                        <Badge className="bg-quantum-alert/20 text-quantum-alert">
                          Error
                        </Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <ShieldAlert className="h-5 w-5 mr-2 text-quantum-cyan" />
                  Quantum Security Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-quantum-navy/50 rounded-md">
                  <p className="text-sm text-white/70 mb-2">All cryptographic protocols are currently using post-quantum algorithms that are resistant to attacks from quantum computers.</p>
                  <p className="text-xs text-quantum-success flex items-center">
                    <span className="h-2 w-2 bg-quantum-success rounded-full mr-1"></span>
                    NIST PQC Round 3 Compliant
                  </p>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/5 border-white/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <AlertCircle className="h-5 w-5 mr-2 text-quantum-cyan" />
                  System Notifications
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="p-3 bg-quantum-alert/10 border border-quantum-alert/20 rounded flex items-start">
                    <AlertCircle className="h-4 w-4 text-quantum-alert mr-2 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">API Rate Limit Warning</p>
                      <p className="text-xs text-white/70">Blockchain endpoint is nearing its daily quota. Consider upgrading plan.</p>
                    </div>
                  </li>
                  <li className="p-3 bg-quantum-warning/10 border border-quantum-warning/20 rounded flex items-start">
                    <AlertCircle className="h-4 w-4 text-quantum-warning mr-2 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-white">Scheduled Maintenance</p>
                      <p className="text-xs text-white/70">System update scheduled for April 10, 2025 at 02:00 UTC.</p>
                    </div>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AdminPage;
