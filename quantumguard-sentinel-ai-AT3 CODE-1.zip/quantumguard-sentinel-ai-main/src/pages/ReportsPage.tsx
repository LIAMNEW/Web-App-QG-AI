
import React, { useState } from 'react';
import { FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { useTransactionStore } from '@/stores/transactionStore';

const ReportsPage: React.FC = () => {
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState('7days');
  const [riskLevel, setRiskLevel] = useState('all');
  const { transactions } = useTransactionStore();

  const handleExport = () => {
    if (transactions.length === 0) {
      toast({
        variant: "destructive",
        title: "No data available",
        description: "Please upload transaction data first."
      });
      return;
    }
    
    // Filter transactions based on selected risk level
    let filteredTransactions = [...transactions];
    if (riskLevel !== 'all') {
      filteredTransactions = transactions.filter(tx => tx.riskScore === riskLevel);
    }
    
    // Convert to CSV
    const headers = ['Transaction ID', 'Sender', 'Receiver', 'Amount', 'Timestamp', 'Status', 'Risk Score'];
    const csvContent = [
      headers.join(','),
      ...filteredTransactions.map(tx => [
        tx.id,
        tx.sender,
        tx.receiver,
        tx.amount,
        tx.timestamp,
        tx.status,
        tx.riskScore
      ].join(','))
    ].join('\n');
    
    // Create download link
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `transaction-report-${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Report generated",
      description: `Your report with ${filteredTransactions.length} transactions has been downloaded.`
    });
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6 text-white">Reports Center</h1>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Generate Transaction Report
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="dateRange" className="text-white">Date Range</Label>
              <Select
                value={dateRange}
                onValueChange={setDateRange}
              >
                <option value="7days">Last 7 Days</option>
                <option value="30days">Last 30 Days</option>
                <option value="90days">Last 90 Days</option>
                <option value="all">All Time</option>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="riskLevel" className="text-white">Risk Level</Label>
              <Select
                value={riskLevel}
                onValueChange={setRiskLevel}
              >
                <option value="all">All Transactions</option>
                <option value="high">High Risk Only</option>
                <option value="medium">Medium Risk Only</option>
                <option value="low">Low Risk Only</option>
              </Select>
            </div>
          </div>
          
          <Button 
            onClick={handleExport}
            className="w-full md:w-auto bg-quantum-cyan hover:bg-quantum-cyan/90"
          >
            <Download className="h-4 w-4 mr-2" />
            Export CSV Report
          </Button>
          
          <div className="text-white/70 text-sm">
            {transactions.length === 0 ? (
              <p>No transaction data available. Please upload data first.</p>
            ) : (
              <p>{transactions.length} transactions available for reporting.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReportsPage;
