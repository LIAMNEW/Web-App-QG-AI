
import React from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Dashboard from '@/components/Dashboard';
import Features from '@/components/Features';
import Footer from '@/components/Footer';
import { useAuth } from '@/context/AuthContext';

const Index: React.FC = () => {
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen bg-quantum-dark text-white">
      <Header />
      <main className="pt-20 sm:pt-16"> {/* Increased mobile padding for larger header */}
        {user ? (
          <>
            <Dashboard />
            <Features />
          </>
        ) : (
          <Hero />
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Index;
