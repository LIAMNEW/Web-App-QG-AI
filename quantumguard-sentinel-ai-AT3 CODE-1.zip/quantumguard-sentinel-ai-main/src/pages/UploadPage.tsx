import React, { useState } from 'react';
import { Upload, ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';
import FileUploadZone from '@/components/upload/FileUploadZone';
import FormatInfo from '@/components/upload/FormatInfo';
import UploadProgress from '@/components/upload/UploadProgress';
import ReportsSection from '@/components/upload/ReportsSection';
import CSVPreview from '@/components/upload/CSVPreview';
import { useFileUpload } from '@/hooks/useFileUpload';
import { parseCSV } from '@/services/csvService';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';

const UploadPage: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<any[]>([]);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const { isLoading, progress, error, handleFileUpload } = useFileUpload();
  const { toast } = useToast();

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'text/csv') {
      processFileForPreview(file);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFileForPreview(file);
    }
  };

  const processFileForPreview = async (file: File) => {
    try {
      const text = await file.text();
      const { transactions } = await parseCSV(text);
      
      if (transactions.length === 0) {
        toast({
          variant: "destructive",
          title: "Invalid CSV",
          description: "No valid transactions found in the file."
        });
        return;
      }

      setPreviewData(transactions);
      setSelectedFile(file);
      setShowPreview(true);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "CSV Parse Error",
        description: error instanceof Error ? error.message : "Failed to parse CSV file"
      });
    }
  };

  const confirmUpload = () => {
    if (selectedFile) {
      setShowPreview(false);
      handleFileUpload(selectedFile);
    }
  };

  const cancelPreview = () => {
    setShowPreview(false);
    setPreviewData([]);
    setSelectedFile(null);
  };

  return (
    <div className="container mx-auto py-6 sm:py-8 px-4 space-y-6 min-h-screen pt-24 sm:pt-20">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-0 mb-6">
        <Link to="/">
          <Button variant="ghost" size="sm" className="mr-0 sm:mr-2 self-start h-10 px-3">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Dashboard
          </Button>
        </Link>
        <h1 className="text-xl sm:text-2xl font-bold text-white">Upload Transactions</h1>
      </div>
      
      <Card className="bg-white/5 border-white/10">
        <CardHeader className="pb-4">
          <CardTitle className="text-white flex items-center gap-2 text-lg sm:text-xl">
            <Upload className="h-5 w-5" />
            Upload Transaction Data
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          {isLoading ? (
            <UploadProgress progress={progress} isLoading={isLoading} />
          ) : showPreview ? (
            <CSVPreview
              parsedData={previewData}
              fileName={selectedFile?.name || 'Unknown'}
              onConfirm={confirmUpload}
              onCancel={cancelPreview}
            />
          ) : (
            <>
              <FileUploadZone
                isDragging={isDragging}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onFileSelect={handleFileSelect}
              />
              <FormatInfo />
            </>
          )}
        </CardContent>
      </Card>

      {/* Reports Section */}
      <ReportsSection />
    </div>
  );
};

export default UploadPage;
