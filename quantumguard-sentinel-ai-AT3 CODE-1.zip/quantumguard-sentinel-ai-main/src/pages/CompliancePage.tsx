
import React from 'react';
import { Shield, ShieldCheck, FileSearch } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const CompliancePage: React.FC = () => {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6 text-white">Compliance & Security</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Shield className="h-5 w-5 text-quantum-cyan" />
              AUSTRAC Compliance
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-white/90">
              QuantumGuard AI is designed to align with AUSTRAC AML/CTF compliance requirements:
            </p>
            <ul className="list-disc list-inside text-white/70 space-y-2">
              <li>Transaction monitoring and reporting</li>
              <li>Risk-based assessment approach</li>
              <li>Audit trail maintenance</li>
              <li>Suspicious activity detection</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <FileSearch className="h-5 w-5 text-quantum-cyan" />
              ASIC Explainability
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-white/90">
              Our AI system provides clear explanations for all risk assessments:
            </p>
            <ul className="list-disc list-inside text-white/70 space-y-2">
              <li>SHAP value analysis for each alert</li>
              <li>Human-readable risk explanations</li>
              <li>Complete audit trails</li>
              <li>Transparent decision processes</li>
            </ul>
          </CardContent>
        </Card>

        <Card className="col-span-1 md:col-span-2 bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-quantum-cyan" />
              Quantum Resilience Roadmap
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-white/90">
              Preparing for the post-quantum era with advanced security measures:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <h3 className="text-quantum-cyan font-medium mb-2">Phase 1: Planning</h3>
                <p className="text-white/70 text-sm">Assessment of quantum vulnerabilities and strategic roadmap development</p>
              </div>
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <h3 className="text-quantum-cyan font-medium mb-2">Phase 2: Implementation</h3>
                <p className="text-white/70 text-sm">Integration of quantum-resistant algorithms and protocols</p>
              </div>
              <div className="p-4 rounded-lg bg-white/5 border border-white/10">
                <h3 className="text-quantum-cyan font-medium mb-2">Phase 3: Validation</h3>
                <p className="text-white/70 text-sm">Testing and certification of quantum-safe security measures</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CompliancePage;
