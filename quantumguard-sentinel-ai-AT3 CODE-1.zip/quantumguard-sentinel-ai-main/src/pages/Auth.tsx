
import React, { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import QSafePasswordField from '@/components/QSafePasswordField';

const authSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

type AuthFormValues = z.infer<typeof authSchema>;

const Auth: React.FC = () => {
  const [isLogin, setIsLogin] = useState(true);
  const { user, signIn, signUp, isLoading } = useAuth();
  const [derivedKey, setDerivedKey] = useState<string | null>(null);

  const form = useForm<AuthFormValues>({
    resolver: zodResolver(authSchema),
    defaultValues: {
      email: '',
      password: '',
    },
  });

  const onSubmit = async (values: AuthFormValues) => {
    try {
      if (isLogin) {
        // Add derived key header for additional security if available
        if (derivedKey) {
          await signIn(values.email, values.password, { 'X-Key-Fingerprint': derivedKey.substring(0, 32) });
        } else {
          await signIn(values.email, values.password);
        }
      } else {
        await signUp(values.email, values.password);
      }
    } catch (error) {
      console.error('Auth error:', error);
      // Error is handled in the auth context
    }
  };

  // Redirect if user is already logged in
  if (user) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-quantum-dark flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md mx-auto">
        <div className="flex justify-center mb-6">
          <Shield className="h-12 w-12 text-quantum-cyan" />
        </div>
        <Card className="bg-quantum-navy border-white/10">
          <CardHeader>
            <CardTitle className="text-white text-center text-2xl">{isLogin ? 'Sign In' : 'Create Account'}</CardTitle>
            <CardDescription className="text-white/70 text-center">
              {isLogin ? 'Access your QuantumGuard dashboard' : 'Join the quantum-secure platform'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Email</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="name@example.com" 
                          className="bg-quantum-dark border-white/20 text-white" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-white">Password</FormLabel>
                      <FormControl>
                        <QSafePasswordField 
                          value={field.value}
                          onChange={field.onChange}
                          onKeyDerivation={setDerivedKey}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full bg-quantum-cyan hover:bg-quantum-cyan/80 text-quantum-dark font-medium"
                  disabled={isLoading}
                >
                  {isLoading ? 'Processing...' : isLogin ? 'Sign In' : 'Create Account'}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button 
              variant="link" 
              className="text-quantum-cyan"
              onClick={() => setIsLogin(!isLogin)}
              disabled={isLoading}
            >
              {isLogin ? 'Need an account? Sign Up' : 'Already have an account? Sign In'}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Auth;
