
import React, { useState, useEffect } from 'react';
import { Shield, Search, AlertTriangle, CheckCircle, FileText, Download, Database, Lock, Zap, Eye, Users } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from './components/ui/card';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from './components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './components/ui/table';
import { Badge } from './components/ui/badge';
import { Button } from './components/ui/button';
import { Progress } from './components/ui/progress';
import { Input } from './components/ui/input';
import { Alert, AlertDescription } from './components/ui/alert';
import { Textarea } from './components/ui/textarea';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Sample data for charts
const analyticsData = [
  { name: 'Jan', value: 42 },
  { name: 'Feb', value: 35 },
  { name: 'Mar', value: 55 },
  { name: 'Apr', value: 38 },
  { name: 'May', value: 68 },
  { name: 'Jun', value: 52 },
  { name: 'Jul', value: 75 },
  { name: 'Aug', value: 90 },
  { name: 'Sep', value: 85 },
  { name: 'Oct', value: 92 },
  { name: 'Nov', value: 75 },
  { name: 'Dec', value: 65 },
];

// Sample transaction data
const sampleTransactions = [
  {
    id: 'tx-8971',
    sender: '0x7Fc9...3b54',
    receiver: '0x3aF1...9c23',
    amount: '12.45 ETH',
    timestamp: '2025-04-07 12:34:21',
    status: 'successful',
    riskScore: 'low',
  },
  {
    id: 'tx-8972',
    sender: '0x2bA3...7e11',
    receiver: '0x9Df2...4a97',
    amount: '0.78 ETH',
    timestamp: '2025-04-07 12:33:15',
    status: 'successful',
    riskScore: 'low',
  },
  {
    id: 'tx-8973',
    sender: '0x5cC7...2f68',
    receiver: '0x1Ee8...8b12',
    amount: '145.00 ETH',
    timestamp: '2025-04-07 12:31:52',
    status: 'suspicious',
    riskScore: 'high',
  },
  {
    id: 'tx-8974',
    sender: '0x4dD2...6a33',
    receiver: '0x8Bc5...3f47',
    amount: '3.21 ETH',
    timestamp: '2025-04-07 12:30:09',
    status: 'successful',
    riskScore: 'low',
  },
  {
    id: 'tx-8975',
    sender: '0x3fF1...9e74',
    receiver: '0x7aC3...2b18',
    amount: '28.50 ETH',
    timestamp: '2025-04-07 12:28:44',
    status: 'successful',
    riskScore: 'medium',
  }
];

// Sample card data
const sampleCardData = [
  {
    id: 1,
    card_brand: 'Visa',
    card_type: 'Credit',
    has_chip: 'Yes',
    num_cards_issued: 3,
    year_pin_last_changed: 2023,
    card_on_dark_web: 'No',
    risk_score: 0.1243,
    explanation: 'Low risk due to recent PIN change and no dark web exposure.'
  },
  {
    id: 2,
    card_brand: 'Mastercard',
    card_type: 'Debit',
    has_chip: 'Yes',
    num_cards_issued: 1,
    year_pin_last_changed: 2020,
    card_on_dark_web: 'No',
    risk_score: 0.3647,
    explanation: 'Medium risk due to older PIN. Consider updating security settings.'
  },
  {
    id: 3,
    card_brand: 'Amex',
    card_type: 'Credit',
    has_chip: 'Yes',
    num_cards_issued: 2,
    year_pin_last_changed: 2019,
    card_on_dark_web: 'Yes',
    risk_score: 0.8976,
    explanation: 'High risk due to dark web exposure. Immediate action recommended.'
  }
];

// RiskScoreCard Component
const RiskScoreCard = ({ score, level, alerts }) => {
  const getScoreColor = () => {
    if (level === 'low') return 'bg-green-500';
    if (level === 'medium') return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Card className="bg-white/5 border border-white/10">
      <CardHeader>
        <CardTitle className="text-white">Risk Score</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center">
          <div className={`relative w-36 h-36 rounded-full ${getScoreColor()} bg-opacity-20 flex items-center justify-center mb-4`}>
            <div className={`absolute w-28 h-28 rounded-full ${getScoreColor()} bg-opacity-40 flex items-center justify-center`}>
              <div className={`w-20 h-20 rounded-full ${getScoreColor()} flex items-center justify-center`}>
                <span className="text-4xl font-bold text-white">{score}</span>
              </div>
            </div>
          </div>
          <div className="text-center">
            <p className="text-white/70">Current Risk Level</p>
            <p className="text-xl font-bold text-white capitalize">{level}</p>
            <div className="mt-4 flex items-center justify-center gap-2">
              <AlertTriangle className="h-5 w-5 text-red-400" />
              <span className="text-white/70">{alerts} Active Alerts</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// AnalyticsChart Component
const AnalyticsChart = () => {
  return (
    <Card className="bg-white/5 border border-white/10">
      <CardHeader>
        <CardTitle className="text-white">Transaction Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[240px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={analyticsData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <defs>
                <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#38bdf8" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis dataKey="name" stroke="#888" />
              <YAxis stroke="#888" />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(30, 30, 30, 0.8)',
                  border: '1px solid #444',
                  color: '#fff',
                }}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="#38bdf8"
                fillOpacity={1}
                fill="url(#colorValue)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
};

// UserProfile Component
const UserProfile = () => {
  return (
    <Card className="bg-white/5 border border-white/10">
      <CardContent className="p-6">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-quantum-cyan to-blue-400 flex items-center justify-center text-2xl font-bold text-white">
              JS
            </div>
            <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-400 rounded-full border-2 border-gray-800"></div>
          </div>
          <div className="text-center sm:text-left">
            <h3 className="text-lg font-medium text-white">Jane Smith</h3>
            <p className="text-quantum-cyan">Security Administrator</p>
            <div className="mt-2 flex flex-wrap gap-2 justify-center sm:justify-start">
              <Badge variant="outline" className="bg-white/5 text-white/70">
                <Shield className="h-3 w-3 mr-1" />
                Level 3 Access
              </Badge>
              <Badge variant="outline" className="bg-white/5 text-white/70">
                <Users className="h-3 w-3 mr-1" />
                Team Lead
              </Badge>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// SmartSearch Component
const SmartSearch = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState(null);

  return (
    <Card className="bg-white/5 border-white/10 text-white">
      <CardHeader>
        <CardTitle className="text-white/90 flex items-center">
          <Search className="h-5 w-5 mr-2 text-quantum-cyan" />
          AI-Powered Transaction Search
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col gap-3">
          <label htmlFor="search-query" className="text-sm font-medium text-white/70">
            Ask any question about the blockchain transactions
          </label>
          <div className="flex gap-2">
            <Input
              id="search-query"
              placeholder="e.g., 'Which transaction has the highest anomaly score?'"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/40"
            />
            <Button 
              className="bg-quantum-cyan hover:bg-quantum-cyan/80 text-quantum-dark"
            >
              Search
            </Button>
          </div>
        </div>

        {result && (
          <div className="mt-6">
            <h3 className="text-sm font-medium text-white/70 mb-2">Results</h3>
            <div className="bg-white/10 border border-white/20 rounded-md p-4 text-white">
              <div className="whitespace-pre-line">{result}</div>
            </div>
          </div>
        )}

        <div className="text-xs text-white/50 mt-4">
          Powered by OpenAI GPT-4o-mini and context-aware transaction analysis
        </div>
      </CardContent>
    </Card>
  );
};

// TransactionAnalysis Component
const TransactionAnalysis = () => {
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin text-quantum-cyan">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-white/10">
      <div className="p-4 border-b border-white/10">
        <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
          <h3 className="text-lg font-medium text-white">Bulk Transaction Analysis</h3>
          <Button variant="outline" className="border-quantum-cyan text-quantum-cyan hover:bg-quantum-cyan/10">
            <Zap className="h-4 w-4 mr-2" />
            Analyze All Pending Transactions
          </Button>
        </div>
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead>Transaction ID</TableHead>
            <TableHead>Feature 1</TableHead>
            <TableHead>Feature 2</TableHead>
            <TableHead>Feature 3</TableHead>
            <TableHead>Feature 4</TableHead>
            <TableHead>Feature 5</TableHead>
            <TableHead>Label</TableHead>
            <TableHead>Risk Score</TableHead>
            <TableHead>Explanation</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          <TableRow className="border-white/10">
            <TableCell className="font-mono">tx-9823</TableCell>
            <TableCell>0.7845</TableCell>
            <TableCell>0.2231</TableCell>
            <TableCell>0.1187</TableCell>
            <TableCell>0.9134</TableCell>
            <TableCell>0.3320</TableCell>
            <TableCell>normal</TableCell>
            <TableCell>0.1243</TableCell>
            <TableCell className="max-w-md truncate">
              Transaction appears normal with typical gas fees and interaction pattern.
            </TableCell>
          </TableRow>
          <TableRow className="border-white/10">
            <TableCell className="font-mono">tx-9824</TableCell>
            <TableCell>0.9912</TableCell>
            <TableCell>0.8845</TableCell>
            <TableCell>0.7734</TableCell>
            <TableCell>0.3325</TableCell>
            <TableCell>0.5567</TableCell>
            <TableCell>suspicious</TableCell>
            <TableCell>0.7854</TableCell>
            <TableCell className="max-w-md truncate">
              High risk due to unusual token swap pattern and known malicious contract interaction.
            </TableCell>
          </TableRow>
          <TableRow className="border-white/10">
            <TableCell className="font-mono">tx-9825</TableCell>
            <TableCell>0.3354</TableCell>
            <TableCell>0.4432</TableCell>
            <TableCell>0.2278</TableCell>
            <TableCell>0.1198</TableCell>
            <TableCell>0.2267</TableCell>
            <TableCell>normal</TableCell>
            <TableCell>0.2156</TableCell>
            <TableCell className="max-w-md truncate">
              Normal transaction with standard token transfer values.
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </div>
  );
};

// CardAIProcessing Component
const CardAIProcessing = () => {
  return (
    <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
      <h3 className="text-lg font-medium text-white">Card Security Analysis</h3>
      <Button variant="outline" className="border-quantum-cyan text-quantum-cyan hover:bg-quantum-cyan/10">
        <Shield className="h-4 w-4 mr-2" />
        Analyze All Card Data
      </Button>
    </div>
  );
};

// CardDataAnalysis Component
const CardDataAnalysis = () => {
  const [isLoading, setIsLoading] = useState(true);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin text-quantum-cyan">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 12a9 9 0 1 1-6.219-8.56" />
          </svg>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-white/10">
      <div className="p-4 border-b border-white/10">
        <CardAIProcessing />
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead>ID</TableHead>
            <TableHead>Card Brand</TableHead>
            <TableHead>Card Type</TableHead>
            <TableHead>Has Chip</TableHead>
            <TableHead>Cards Issued</TableHead>
            <TableHead>PIN Changed</TableHead>
            <TableHead>Dark Web</TableHead>
            <TableHead>Risk Score</TableHead>
            <TableHead>Explanation</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sampleCardData.map((card) => (
            <TableRow key={card.id} className="border-white/10">
              <TableCell className="font-mono">{card.id}</TableCell>
              <TableCell>{card.card_brand || 'Unknown'}</TableCell>
              <TableCell>{card.card_type || 'Unknown'}</TableCell>
              <TableCell>{card.has_chip || 'Unknown'}</TableCell>
              <TableCell>{card.num_cards_issued || 'Unknown'}</TableCell>
              <TableCell>{card.year_pin_last_changed || 'Unknown'}</TableCell>
              <TableCell>{card.card_on_dark_web || 'Unknown'}</TableCell>
              <TableCell>
                {card.risk_score !== null ? Number(card.risk_score).toFixed(4) : 'Pending'}
              </TableCell>
              <TableCell className="max-w-md truncate">
                {card.explanation || 'Pending analysis'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

// TransactionList Component
const TransactionList = () => {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead className="text-white/70">Transaction ID</TableHead>
            <TableHead className="text-white/70">Sender</TableHead>
            <TableHead className="text-white/70">Receiver</TableHead>
            <TableHead className="text-white/70">Amount</TableHead>
            <TableHead className="text-white/70">Timestamp</TableHead>
            <TableHead className="text-white/70">Status</TableHead>
            <TableHead className="text-white/70">Risk Score</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sampleTransactions.map((tx) => (
            <TableRow key={tx.id} className="border-white/10">
              <TableCell className="font-mono text-quantum-cyan">{tx.id}</TableCell>
              <TableCell className="font-mono">{tx.sender}</TableCell>
              <TableCell className="font-mono">{tx.receiver}</TableCell>
              <TableCell>{tx.amount}</TableCell>
              <TableCell>{tx.timestamp}</TableCell>
              <TableCell>
                {tx.status === 'successful' ? (
                  <Badge className="bg-quantum-success/20 text-quantum-success border-quantum-success/20 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />
                    Successful
                  </Badge>
                ) : (
                  <Badge className="bg-quantum-alert/20 text-quantum-alert border-quantum-alert/20 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    Suspicious
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                {tx.riskScore === 'low' && (
                  <Badge className="bg-quantum-success/20 text-quantum-success border-quantum-success/20">
                    Low
                  </Badge>
                )}
                {tx.riskScore === 'medium' && (
                  <Badge className="bg-quantum-warning/20 text-quantum-warning border-quantum-warning/20">
                    Medium
                  </Badge>
                )}
                {tx.riskScore === 'high' && (
                  <Badge className="bg-quantum-alert/20 text-quantum-alert border-quantum-alert/20">
                    High
                  </Badge>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

// Main Dashboard Component
const QuantumGuardDashboard: React.FC = () => {
  return (
    <section className="py-8 px-4 bg-quantum-dark text-white min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <div className="flex items-center gap-3">
            <Shield className="h-7 w-7 text-quantum-cyan" />
            <h2 className="text-2xl md:text-3xl font-bold text-white">Blockchain Security Dashboard</h2>
          </div>
          <p className="text-white/70 mt-1">Real-time monitoring and quantum-resilient security</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <RiskScoreCard score={42} level="medium" alerts={3} />
          <div className="lg:col-span-2">
            <AnalyticsChart />
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="space-y-6">
            <UserProfile />
            <SmartSearch />
          </div>
          <div className="lg:col-span-2">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <h3 className="text-lg font-medium text-white mb-4">Data Analysis</h3>
              
              <Tabs defaultValue="transactions" className="mb-6">
                <TabsList className="mb-4 bg-white/5">
                  <TabsTrigger value="transactions">Transactions</TabsTrigger>
                  <TabsTrigger value="cards">Card Data</TabsTrigger>
                </TabsList>
                
                <TabsContent value="transactions">
                  <TransactionAnalysis />
                </TabsContent>
                
                <TabsContent value="cards">
                  <CardDataAnalysis />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6 mb-6">
          <Card className="bg-white/5 border border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5 text-quantum-cyan" />
                Recent Transactions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TransactionList />
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="bg-white/5 border border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5 text-quantum-cyan" />
                Security Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 border border-white/10 rounded-lg bg-white/5">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-white font-medium">Update Multi-Factor Authentication</h4>
                  <Badge className="bg-quantum-warning/20 text-quantum-warning border-quantum-warning/20">Medium</Badge>
                </div>
                <p className="text-white/70 text-sm mb-3">Enable hardware key authentication for admin accounts</p>
                <Button size="sm" variant="outline" className="border-quantum-cyan text-quantum-cyan text-xs hover:bg-quantum-cyan/10">
                  View Details
                </Button>
              </div>
              
              <div className="p-4 border border-white/10 rounded-lg bg-white/5">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-white font-medium">Contract Vulnerability</h4>
                  <Badge className="bg-quantum-alert/20 text-quantum-alert border-quantum-alert/20">High</Badge>
                </div>
                <p className="text-white/70 text-sm mb-3">Critical reentrancy vulnerability detected in smart contract</p>
                <Button size="sm" variant="outline" className="border-quantum-cyan text-quantum-cyan text-xs hover:bg-quantum-cyan/10">
                  View Details
                </Button>
              </div>
              
              <div className="p-4 border border-white/10 rounded-lg bg-white/5">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-white font-medium">Update SSL Certificate</h4>
                  <Badge className="bg-quantum-success/20 text-quantum-success border-quantum-success/20">Low</Badge>
                </div>
                <p className="text-white/70 text-sm mb-3">SSL certificate expires in 45 days</p>
                <Button size="sm" variant="outline" className="border-quantum-cyan text-quantum-cyan text-xs hover:bg-quantum-cyan/10">
                  View Details
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/5 border border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-quantum-cyan" />
                Monitoring Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">Node Status</span>
                  <span className="text-quantum-success">Online</span>
                </div>
                <Progress value={100} className="h-2 bg-white/10">
                  <div className="h-full bg-quantum-success" style={{ width: '100%' }} />
                </Progress>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">Smart Contract Scanner</span>
                  <span className="text-quantum-success">Active</span>
                </div>
                <Progress value={100} className="h-2 bg-white/10">
                  <div className="h-full bg-quantum-success" style={{ width: '100%' }} />
                </Progress>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">Quantum Encryption</span>
                  <span className="text-quantum-warning">Partial</span>
                </div>
                <Progress value={72} className="h-2 bg-white/10">
                  <div className="h-full bg-quantum-warning" style={{ width: '72%' }} />
                </Progress>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">AI Analysis</span>
                  <span className="text-quantum-success">Active</span>
                </div>
                <Progress value={96} className="h-2 bg-white/10">
                  <div className="h-full bg-quantum-success" style={{ width: '96%' }} />
                </Progress>
              </div>
              
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-white/70">Dark Web Monitoring</span>
                  <span className="text-quantum-warning">Partial</span>
                </div>
                <Progress value={65} className="h-2 bg-white/10">
                  <div className="h-full bg-quantum-warning" style={{ width: '65%' }} />
                </Progress>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default QuantumGuardDashboard;
