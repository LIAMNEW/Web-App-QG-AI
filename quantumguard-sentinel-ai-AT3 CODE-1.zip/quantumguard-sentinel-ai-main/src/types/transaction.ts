
export interface Transaction {
  id: string;
  sender: string;
  receiver: string;
  amount: string;
  timestamp: string;
  status: 'successful' | 'suspicious' | 'failed';
  riskScore: 'low' | 'medium' | 'high';
  // Database transaction properties
  feature_1?: number;
  feature_2?: number;
  feature_3?: number;
  feature_4?: number;
  feature_5?: number;
  label?: string;
  risk_score?: number;
  explanation?: string;
  transaction_id?: string;
  created_at?: string;
}
