
import { create } from 'zustand';
import { Transaction } from '@/types/transaction';

interface TransactionState {
  transactions: Transaction[];
  addTransactions: (newTransactions: Transaction[]) => void;
  addTransaction: (transaction: Transaction) => void;
  clearTransactions: () => void;
  replaceTransactions: (newTransactions: Transaction[]) => void;
}

export const useTransactionStore = create<TransactionState>((set) => ({
  transactions: [],
  
  addTransactions: (newTransactions) => 
    set((state) => ({ 
      transactions: [...newTransactions, ...state.transactions]
    })),
  
  addTransaction: (transaction) => 
    set((state) => ({
      transactions: [transaction, ...state.transactions]
    })),
  
  clearTransactions: () => set({ transactions: [] }),
  
  replaceTransactions: (newTransactions) => 
    set({ transactions: newTransactions }),
}));
