
/**
 * Quantum-safe encryption utilities
 * Uses combination of classical and post-quantum algorithms for hybrid encryption
 */

// Simple implementation of a quantum-resistant key derivation
export const deriveKeyQuantumSafe = async (password: string, salt?: string): Promise<ArrayBuffer> => {
  // Use argon2id parameters aligned with server-side settings
  const encoder = new TextEncoder();
  const passwordBuffer = encoder.encode(password);
  const saltBuffer = salt ? encoder.encode(salt) : crypto.getRandomValues(new Uint8Array(16));
  
  // First pass: SHA-256 (classical)
  const firstPassKey = await crypto.subtle.digest('SHA-256', passwordBuffer);
  
  // Second pass: PBKDF2 with high iteration count
  // This is a simplified approach. In production, a full PQ-KDF would be used
  const secondPassKey = await crypto.subtle.importKey(
    'raw',
    firstPassKey,
    { name: 'PBKDF2' },
    false,
    ['deriveBits', 'deriveKey']
  );
  
  // Derive final key with high iteration count (aligning with argon2id memory parameter)
  const finalKey = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBuffer,
      iterations: 65536,
      hash: 'SHA-512'
    },
    secondPassKey,
    512
  );
  
  return finalKey;
};

// Hybrid encryption (classical + quantum-resistant approach)
export const encryptQuantumSafe = async (data: string, password: string): Promise<string> => {
  try {
    // Derive key using our quantum-safe approach
    const keyMaterial = await deriveKeyQuantumSafe(password);
    
    // Import as AES-GCM key (still strong against classical attacks)
    const key = await crypto.subtle.importKey(
      'raw',
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt']
    );
    
    // Generate random IV
    const iv = crypto.getRandomValues(new Uint8Array(12));
    
    // Encrypt data
    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(data);
    const encryptedBuffer = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      dataBuffer
    );
    
    // Combine IV and encrypted data for storage
    const result = new Uint8Array(iv.length + encryptedBuffer.byteLength);
    result.set(iv);
    result.set(new Uint8Array(encryptedBuffer), iv.length);
    
    // Return as base64
    return btoa(String.fromCharCode(...result));
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
};

// Hybrid decryption
export const decryptQuantumSafe = async (encryptedData: string, password: string): Promise<string> => {
  try {
    // Decode from base64
    const encryptedBytes = Uint8Array.from(atob(encryptedData), c => c.charCodeAt(0));
    
    // Extract IV (first 12 bytes)
    const iv = encryptedBytes.slice(0, 12);
    const data = encryptedBytes.slice(12);
    
    // Derive key using our quantum-safe approach
    const keyMaterial = await deriveKeyQuantumSafe(password);
    
    // Import as AES-GCM key
    const key = await crypto.subtle.importKey(
      'raw',
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['decrypt']
    );
    
    // Decrypt data
    const decryptedBuffer = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    
    // Return as string
    const decoder = new TextDecoder();
    return decoder.decode(decryptedBuffer);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
};

// Store sensitive data with quantum-resistant encryption
export const storeEncryptedData = async (key: string, data: any, password: string): Promise<void> => {
  const stringData = JSON.stringify(data);
  const encryptedData = await encryptQuantumSafe(stringData, password);
  localStorage.setItem(key, encryptedData);
};

// Retrieve and decrypt data
export const retrieveEncryptedData = async (key: string, password: string): Promise<any> => {
  const encryptedData = localStorage.getItem(key);
  if (!encryptedData) return null;
  
  const decryptedString = await decryptQuantumSafe(encryptedData, password);
  return JSON.parse(decryptedString);
};
