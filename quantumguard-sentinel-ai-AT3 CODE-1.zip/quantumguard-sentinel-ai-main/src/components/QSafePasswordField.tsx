
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Eye, EyeOff, Shield } from 'lucide-react';
import { deriveKeyQuantumSafe } from '@/utils/quantumSafeEncryption';

interface QSafePasswordFieldProps {
  value: string;
  onChange: (value: string) => void;
  onKeyDerivation?: (derivedKey: string) => void;
  className?: string;
  placeholder?: string;
}

const QSafePasswordField: React.FC<QSafePasswordFieldProps> = ({
  value,
  onChange,
  onKeyDerivation,
  className = '',
  placeholder = '••••••••'
}) => {
  const [showPassword, setShowPassword] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState<number>(0);
  
  // Check password strength
  const checkPasswordStrength = (password: string) => {
    if (!password) return 0;
    
    let strength = 0;
    
    // Length check
    if (password.length >= 12) strength += 25;
    else if (password.length >= 8) strength += 15;
    else if (password.length >= 6) strength += 10;
    
    // Complexity checks
    if (/[A-Z]/.test(password)) strength += 15; // Uppercase
    if (/[a-z]/.test(password)) strength += 10; // Lowercase
    if (/[0-9]/.test(password)) strength += 15; // Numbers
    if (/[^A-Za-z0-9]/.test(password)) strength += 20; // Special chars
    if (/(.)\1\1\1/.test(password)) strength -= 15; // Repeated characters
    
    // Entropy bonus for longer passwords
    strength += Math.min(15, password.length - 8);
    
    return Math.min(100, Math.max(0, strength));
  };
  
  const handlePasswordChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    onChange(newPassword);
    
    // Update password strength
    setPasswordStrength(checkPasswordStrength(newPassword));
    
    // If onKeyDerivation is provided, derive a key
    if (onKeyDerivation && newPassword) {
      try {
        const derivedKey = await deriveKeyQuantumSafe(newPassword);
        // Convert ArrayBuffer to hex string for transport/storage
        const keyArray = Array.from(new Uint8Array(derivedKey));
        const keyHex = keyArray.map(b => b.toString(16).padStart(2, '0')).join('');
        onKeyDerivation(keyHex);
      } catch (error) {
        console.error("Key derivation error:", error);
      }
    }
  };
  
  const getStrengthColor = () => {
    if (passwordStrength >= 80) return "bg-quantum-success";
    if (passwordStrength >= 60) return "bg-green-500";
    if (passwordStrength >= 40) return "bg-yellow-500";
    if (passwordStrength >= 20) return "bg-orange-500";
    return "bg-red-500";
  };

  return (
    <div className="space-y-2">
      <div className="relative">
        <Input
          type={showPassword ? "text" : "password"}
          value={value}
          onChange={handlePasswordChange}
          className={`pr-10 bg-quantum-dark border-white/20 text-white ${className}`}
          placeholder={placeholder}
        />
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="absolute right-0 top-0 h-full text-white/70 hover:text-white"
          onClick={() => setShowPassword(!showPassword)}
        >
          {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
        </Button>
      </div>
      
      {value && (
        <>
          <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
            <div 
              className={`h-full ${getStrengthColor()} transition-all duration-300`}
              style={{ width: `${passwordStrength}%` }}
            />
          </div>
          <div className="flex items-center gap-1 text-xs">
            <Shield size={12} className="text-quantum-cyan" />
            <span className="text-white/70">
              {passwordStrength < 40 && "Weak password"}
              {passwordStrength >= 40 && passwordStrength < 70 && "Moderate password"}
              {passwordStrength >= 70 && "Strong password"}
            </span>
          </div>
        </>
      )}
    </div>
  );
};

export default QSafePasswordField;
