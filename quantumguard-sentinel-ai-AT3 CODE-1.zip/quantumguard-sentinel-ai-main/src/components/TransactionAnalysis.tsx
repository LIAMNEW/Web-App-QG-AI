
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { BulkAIProcessing } from "./BulkAIProcessing";
import { useState, useEffect } from "react";

export function TransactionAnalysis() {
  // Fetch transactions with React Query
  const { data: transactions, error, isLoading } = useQuery({
    queryKey: ["transactions"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("transactions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);
      
      if (error) throw error;
      return data;
    },
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  // Set up real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('schema-db-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions'
        },
        (payload) => {
          console.log('Change received!', payload);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-quantum-cyan" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Error loading transactions: {error.message}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-white/10">
      <div className="p-4 border-b border-white/10">
        <BulkAIProcessing />
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead>Transaction ID</TableHead>
            <TableHead>Feature 1</TableHead>
            <TableHead>Feature 2</TableHead>
            <TableHead>Feature 3</TableHead>
            <TableHead>Feature 4</TableHead>
            <TableHead>Feature 5</TableHead>
            <TableHead>Label</TableHead>
            <TableHead>Risk Score</TableHead>
            <TableHead>Explanation</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions?.map((tx) => (
            <TableRow key={tx.id} className="border-white/10">
              <TableCell className="font-mono">{tx.transaction_id}</TableCell>
              <TableCell>{tx.feature_1?.toFixed(4)}</TableCell>
              <TableCell>{tx.feature_2?.toFixed(4)}</TableCell>
              <TableCell>{tx.feature_3?.toFixed(4)}</TableCell>
              <TableCell>{tx.feature_4?.toFixed(4)}</TableCell>
              <TableCell>{tx.feature_5?.toFixed(4)}</TableCell>
              <TableCell>{tx.label}</TableCell>
              <TableCell>
                {tx.risk_score !== null ? tx.risk_score.toFixed(4) : 'Pending'}
              </TableCell>
              <TableCell className="max-w-md truncate">
                {tx.explanation || 'Pending analysis'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
