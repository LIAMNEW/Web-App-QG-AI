import React, { useState } from 'react';
import { Search, RefreshCw, Wifi, WifiOff, RotateCcw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { InfoIcon } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const SmartSearch: React.FC = () => {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [useLocalSearch, setUseLocalSearch] = useState(false);
  const [lightweightMode, setLightweightMode] = useState(false);
  const { toast } = useToast();

  const performLocalSearch = async (searchQuery: string) => {
    try {
      const { data: transactions, error } = await supabase
        .from('transactions')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;

      if (!transactions?.length) {
        return "No transaction data found. Please upload a CSV file first.";
      }

      const lowerQuery = searchQuery.toLowerCase();
      
      if (lowerQuery.includes('highest risk') || lowerQuery.includes('most suspicious')) {
        const sorted = [...transactions].sort((a, b) => (b.risk_score || 0) - (a.risk_score || 0));
        const highest = sorted[0];
        return `Transaction ${highest.transaction_id} has the highest risk score of ${((highest.risk_score || 0) * 100).toFixed(1)}%. ${highest.explanation || 'No additional details available.'}`;
      }
      
      if (lowerQuery.includes('lowest risk') || lowerQuery.includes('safest')) {
        const sorted = [...transactions].sort((a, b) => (a.risk_score || 0) - (b.risk_score || 0));
        const lowest = sorted[0];
        return `Transaction ${lowest.transaction_id} has the lowest risk score of ${((lowest.risk_score || 0) * 100).toFixed(1)}%. This appears to be the safest transaction.`;
      }
      
      if (lowerQuery.includes('fraud') || lowerQuery.includes('fraudulent')) {
        const fraudulent = transactions.filter(t => t.label === 'fraud' || (t.risk_score && t.risk_score > 0.7));
        return `Found ${fraudulent.length} potentially fraudulent transactions out of ${transactions.length} total transactions (${((fraudulent.length / transactions.length) * 100).toFixed(1)}% fraud rate).`;
      }
      
      if (lowerQuery.includes('total') || lowerQuery.includes('count')) {
        return `Database contains ${transactions.length} transactions. ${transactions.filter(t => t.label === 'fraud').length} are labeled as fraudulent.`;
      }
      
      return `Found ${transactions.length} transactions in the database. Average risk score is ${(transactions.reduce((sum, t) => sum + (t.risk_score || 0), 0) / transactions.length * 100).toFixed(1)}%. Try asking about "highest risk", "fraud", or "total count".`;
      
    } catch (error) {
      console.error('Local search error:', error);
      return "Error performing search. Please try again.";
    }
  };

  const handleSearch = async () => {
    if (!query.trim()) {
      toast({
        title: "Empty Query",
        description: "Please enter a search query.",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    setResult(null);

    try {
      if (lightweightMode) {
        const localResult = await performLocalSearch(query);
        setResult(localResult);
        setUseLocalSearch(true);
        return;
      }

      const { data, error } = await supabase.functions.invoke('smart-search', {
        body: {
          query: query,
          contextData: [],
        },
      });

      if (error) {
        console.log("Edge function unavailable, using local search");
        setUseLocalSearch(true);
        const localResult = await performLocalSearch(query);
        setResult(localResult);
      } else {
        setResult(data.result);
        setUseLocalSearch(false);
      }
    } catch (error) {
      console.log("Edge function failed, using local search");
      setUseLocalSearch(true);
      const localResult = await performLocalSearch(query);
      setResult(localResult);
    } finally {
      setIsSearching(false);
    }
  };

  const retryWithAI = async () => {
    if (lightweightMode) {
      setLightweightMode(false);
    }
    await handleSearch();
  };

  return (
    <Card className="bg-white/5 border-white/10 text-white">
      <CardHeader className="pb-4">
        <CardTitle className="text-white/90 flex items-center justify-between">
          <div className="flex items-center">
            <Search className="h-5 w-5 mr-2 text-quantum-cyan" />
            AI-Powered Transaction Search
          </div>
          {/* Lightweight Mode Toggle */}
          <div className="flex items-center space-x-2 text-sm">
            <WifiOff className={`h-4 w-4 ${lightweightMode ? 'text-orange-400' : 'text-white/30'}`} />
            <Switch
              checked={lightweightMode}
              onCheckedChange={setLightweightMode}
              className="data-[state=checked]:bg-orange-500"
            />
            <Wifi className={`h-4 w-4 ${!lightweightMode ? 'text-quantum-cyan' : 'text-white/30'}`} />
          </div>
        </CardTitle>
        {lightweightMode && (
          <div className="text-xs text-orange-300/80 mt-1">
            Lightweight mode: Using local search only for better performance on slow connections
          </div>
        )}
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Enhanced Local Search Mode Alert */}
        {useLocalSearch && !lightweightMode && (
          <Alert className="bg-gradient-to-r from-blue-950/80 to-indigo-950/80 border-blue-400/50 shadow-lg">
            <div className="flex items-start justify-between">
              <div className="flex">
                <InfoIcon className="h-5 w-5 text-blue-400 mt-0.5 mr-3 flex-shrink-0" />
                <div>
                  <AlertTitle className="text-blue-300 font-semibold text-base">
                    🔍 Local Search Mode Active
                  </AlertTitle>
                  <AlertDescription className="text-blue-100/80 mt-1">
                    AI search temporarily unavailable. Using local database analysis.
                    <br />
                    <span className="text-blue-200 font-medium">Try:</span> "highest risk", "fraud count", "total transactions"
                  </AlertDescription>
                </div>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={retryWithAI}
                className="border-blue-400/50 text-blue-300 hover:bg-blue-900/50 ml-4 flex-shrink-0"
              >
                <RefreshCw className="h-3 w-3 mr-1" />
                Retry AI
              </Button>
            </div>
          </Alert>
        )}

        <div className="space-y-4">
          <label htmlFor="search-query" className="text-sm font-medium text-white/70 block">
            Ask any question about the blockchain transactions
          </label>
          
          {/* Mobile-optimized search interface */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              id="search-query"
              placeholder="e.g., 'Which transaction has the highest risk score?'"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/40 h-12 sm:h-10 text-base sm:text-sm px-4"
              onKeyDown={(e) => e.key === 'Enter' && !isSearching && handleSearch()}
            />
            <Button 
              onClick={handleSearch} 
              disabled={isSearching}
              className="bg-quantum-cyan hover:bg-quantum-cyan/80 text-quantum-dark h-12 sm:h-10 px-6 font-medium text-base sm:text-sm min-w-[120px]"
            >
              {isSearching ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </>
              )}
            </Button>
          </div>
        </div>

        {/* Enhanced Results Display */}
        {result && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-medium text-white/90">Search Results</h3>
              {useLocalSearch && (
                <span className="text-xs bg-blue-500/20 text-blue-300 px-2 py-1 rounded-full">
                  Local Analysis
                </span>
              )}
            </div>
            <div className="bg-gradient-to-br from-white/10 to-white/5 border border-white/20 rounded-lg p-4 sm:p-6 text-white shadow-lg">
              <div className="whitespace-pre-line leading-relaxed text-sm sm:text-base">{result}</div>
            </div>
          </div>
        )}

        {/* Enhanced Footer with Mode Information */}
        <div className="text-xs text-white/50 bg-white/5 rounded-md p-3 border-l-2 border-quantum-cyan/30">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <span>
              {lightweightMode 
                ? '⚡ Lightweight local search for optimal mobile performance'
                : useLocalSearch 
                  ? '🔍 Local database search with intelligent pattern matching'
                  : '🤖 Powered by OpenAI GPT-4o-mini with context-aware analysis'
              }
            </span>
            {!lightweightMode && (
              <span className="text-white/40">
                Toggle lightweight mode for slow connections →
              </span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default SmartSearch;
