
import React from 'react';
import { Shield, Activity, Database, Check } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const features = [
  {
    icon: <Activity className="h-8 w-8 text-quantum-cyan" />,
    title: 'AI-Powered Fraud Detection',
    description: 'Machine learning models analyze blockchain transaction patterns in real time to spot anomalies and potential fraud.'
  },
  {
    icon: <Database className="h-8 w-8 text-quantum-cyan" />,
    title: 'Blockchain Simulation',
    description: 'Simulates blockchain environments to demonstrate how QuantumGuard monitors crypto transactions with realistic data.'
  },
  {
    icon: <Shield className="h-8 w-8 text-quantum-cyan" />,
    title: 'Quantum-Resilience',
    description: 'Future-proofed against quantum computing threats with post-quantum cryptographic techniques for long-term data protection.'
  },
  {
    icon: <Check className="h-8 w-8 text-quantum-cyan" />,
    title: 'Real-World Ready',
    description: 'Designed with input from financial institutions and integrates compliance checks required by regulators.'
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-20 px-4 lg:px-8 bg-gradient-to-b from-quantum-dark to-quantum-navy">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Key Features</h2>
          <p className="text-lg text-white/70 max-w-2xl mx-auto">
            QuantumGuard Sentinel AI combines cutting-edge technologies to provide unparalleled security for blockchain transactions
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 hover:translate-y-[-5px]">
              <CardContent className="p-6 text-white">
                <div className="mb-4 p-3 rounded-lg inline-block bg-quantum-navy">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
