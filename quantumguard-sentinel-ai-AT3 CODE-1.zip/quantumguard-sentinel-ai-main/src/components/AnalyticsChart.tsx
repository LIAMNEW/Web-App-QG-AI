
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useDynamicAnalytics } from './DynamicAnalytics';

const AnalyticsChart: React.FC = () => {
  const { recentActivity, totalTransactions } = useDynamicAnalytics();

  return (
    <Card className="bg-white/5 border-white/10 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-white/90 flex items-center">
          <Activity className="h-5 w-5 mr-2 text-quantum-cyan" />
          24-Hour Network Activity ({totalTransactions} total transactions)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={recentActivity}
              margin={{ top: 5, right: 30, left: 0, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" />
              <XAxis dataKey="name" stroke="#ffffff50" fontSize={12} />
              <YAxis stroke="#ffffff50" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#1a1f2e', 
                  border: '1px solid #ffffff20',
                  borderRadius: '4px',
                  color: 'white' 
                }} 
              />
              <Line 
                type="monotone" 
                dataKey="riskScore" 
                stroke="#FF6B6B" 
                strokeWidth={2} 
                name="Risk Score"
                dot={{ strokeWidth: 2, r: 4 }} 
                activeDot={{ r: 6 }} 
              />
              <Line 
                type="monotone" 
                dataKey="transactions" 
                stroke="#00D8FF" 
                strokeWidth={2} 
                name="Transactions"
                dot={{ strokeWidth: 2, r: 4 }} 
                activeDot={{ r: 6 }} 
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex justify-between mt-4 text-sm text-white/70">
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 bg-[#00D8FF] rounded-full"></div>
            <span>Transactions</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="h-3 w-3 bg-[#FF6B6B] rounded-full"></div>
            <span>Risk Score</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AnalyticsChart;
