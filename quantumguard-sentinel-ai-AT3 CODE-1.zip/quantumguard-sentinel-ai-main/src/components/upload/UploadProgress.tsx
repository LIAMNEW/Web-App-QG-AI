
import React from 'react';
import { Progress } from '@/components/ui/progress';

interface UploadProgressProps {
  progress: number;
  isLoading: boolean;
}

const UploadProgress: React.FC<UploadProgressProps> = ({ progress, isLoading }) => {
  if (!isLoading) return null;

  return (
    <div className="space-y-4">
      <p className="text-white/90 text-center">
        Processing your file... {Math.round(progress)}%
      </p>
      <Progress value={progress} className="h-2 bg-white/10">
        <div 
          className="h-full bg-quantum-cyan transition-all duration-300" 
          style={{ width: `${progress}%` }} 
        />
      </Progress>
    </div>
  );
};

export default UploadProgress;
