
import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

const SampleDataDownload: React.FC = () => {
  const generateSampleData = () => {
    const headers = ['txid', 'feature_1', 'feature_2', 'feature_3', 'feature_4', 'feature_5', 'class'];
    const rows = [];
    
    // Generate 100 sample transactions with realistic feature values
    for (let i = 1; i <= 100; i++) {
      const txid = `tx${String(i).padStart(4, '0')}`;
      
      // Generate features between -1 and 1 (typical for normalized data)
      const feature_1 = (Math.random() * 2 - 1).toFixed(6);
      const feature_2 = (Math.random() * 2 - 1).toFixed(6);
      const feature_3 = (Math.random() * 2 - 1).toFixed(6);
      const feature_4 = (Math.random() * 2 - 1).toFixed(6);
      const feature_5 = (Math.random() * 2 - 1).toFixed(6);
      
      // Create realistic distribution: 85% legitimate (class 2), 15% fraud (class 1)
      const isFraud = Math.random() < 0.15;
      const classification = isFraud ? '1' : '2';
      
      // If fraud, bias some features to be more extreme
      if (isFraud) {
        // Make some features more extreme for fraudulent transactions
        const extremeFeature1 = Math.random() > 0.5 ? (0.7 + Math.random() * 0.3) : (-0.7 - Math.random() * 0.3);
        const extremeFeature2 = Math.random() > 0.5 ? (0.6 + Math.random() * 0.4) : (-0.6 - Math.random() * 0.4);
        
        rows.push([
          txid,
          extremeFeature1.toFixed(6),
          extremeFeature2.toFixed(6),
          feature_3,
          feature_4,
          feature_5,
          classification
        ]);
      } else {
        rows.push([
          txid,
          feature_1,
          feature_2,
          feature_3,
          feature_4,
          feature_5,
          classification
        ]);
      }
    }
    
    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    return csvContent;
  };

  const handleDownload = () => {
    const csvContent = generateSampleData();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `elliptic_sample_transactions_${Date.now()}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="mt-4 p-4 border border-white/10 rounded-lg bg-white/5">
      <h4 className="text-white font-medium mb-2">Need Sample Data?</h4>
      <p className="text-white/70 text-sm mb-3">
        Download a sample dataset in Elliptic format with 100 transactions including fraud detection features.
      </p>
      <Button 
        onClick={handleDownload}
        variant="outline" 
        size="sm"
        className="hover:bg-quantum-cyan/20"
      >
        <Download className="h-4 w-4 mr-2" />
        Download Sample Dataset (Elliptic Format)
      </Button>
      <div className="mt-2 text-xs text-white/50">
        Format: txid, feature_1-5, class (1=fraud, 2=legitimate)
      </div>
    </div>
  );
};

export default SampleDataDownload;
