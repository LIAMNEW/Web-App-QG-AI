
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, CheckCircle, AlertCircle } from 'lucide-react';

interface ParsedTransaction {
  id?: string;
  sender?: string;
  receiver?: string;
  amount?: string;
  timestamp?: string;
  [key: string]: any;
}

interface CSVPreviewProps {
  parsedData: ParsedTransaction[];
  fileName: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const CSVPreview: React.FC<CSVPreviewProps> = ({ 
  parsedData, 
  fileName, 
  onConfirm, 
  onCancel 
}) => {
  const previewRows = parsedData.slice(0, 5);
  const totalRows = parsedData.length;
  
  // Detect columns for display
  const sampleRow = parsedData[0] || {};
  const columns = Object.keys(sampleRow);
  const displayColumns = columns.slice(0, 6); // Show max 6 columns
  
  const hasValidData = parsedData.length > 0 && 
    (sampleRow.sender || sampleRow.receiver || sampleRow.amount);

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Eye className="h-5 w-5 text-quantum-cyan" />
          CSV Preview - {fileName}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {hasValidData ? (
              <CheckCircle className="h-4 w-4 text-green-400" />
            ) : (
              <AlertCircle className="h-4 w-4 text-orange-400" />
            )}
            <span className="text-white/90">
              {totalRows} transactions detected
            </span>
          </div>
          <span className="text-white/70 text-sm">
            Showing first 5 rows
          </span>
        </div>

        {/* Preview table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/20">
                {displayColumns.map((column, index) => (
                  <th key={index} className="text-left p-2 text-white/80 font-medium">
                    {column}
                  </th>
                ))}
                {columns.length > 6 && (
                  <th className="text-left p-2 text-white/80 font-medium">
                    +{columns.length - 6} more...
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {previewRows.map((row, rowIndex) => (
                <tr key={rowIndex} className="border-b border-white/10 hover:bg-white/5">
                  {displayColumns.map((column, colIndex) => (
                    <td key={colIndex} className="p-2 text-white/70">
                      <div className="max-w-32 truncate" title={String(row[column] || '')}>
                        {String(row[column] || '-')}
                      </div>
                    </td>
                  ))}
                  {columns.length > 6 && (
                    <td className="p-2 text-white/50">...</td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Data quality indicators */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-white/10">
          <div className="text-center">
            <div className="text-lg font-bold text-white">
              {parsedData.filter(row => row.sender).length}
            </div>
            <div className="text-white/70 text-xs">With Sender</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-white">
              {parsedData.filter(row => row.receiver).length}
            </div>
            <div className="text-white/70 text-xs">With Receiver</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-white">
              {parsedData.filter(row => row.amount).length}
            </div>
            <div className="text-white/70 text-xs">With Amount</div>
          </div>
          <div className="text-center">
            <div className="text-lg font-bold text-white">
              {parsedData.filter(row => row.timestamp).length}
            </div>
            <div className="text-white/70 text-xs">With Timestamp</div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex gap-3 pt-4">
          <Button 
            onClick={onConfirm}
            className="flex-1 bg-quantum-cyan hover:bg-quantum-cyan/90"
            disabled={!hasValidData}
          >
            Confirm & Upload
          </Button>
          <Button 
            onClick={onCancel}
            variant="outline"
            className="flex-1 hover:bg-white/10"
          >
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CSVPreview;
