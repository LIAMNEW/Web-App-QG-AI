
import React from 'react';
import { HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const sampleCsvContent = `txid,source,target,amount,timestamp,class
tx1234,0x8a23b2,0x9c45d1,25.5,2023-04-15 12:30:00,2
tx1235,0xa1c7e3,0xb2d8f4,103.2,2023-04-15 12:35:00,1
tx1236,0xc3e9g5,0xd4f0h6,5.7,2023-04-15 12:40:00,2`;

const FormatInfo: React.FC = () => {
  return (
    <div className="text-sm text-white/70 mt-4 flex flex-col items-center">
      <p>The system supports Elliptic Bitcoin dataset formats.</p>
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="sm" className="flex items-center text-quantum-cyan mt-2">
            <HelpCircle className="h-3 w-3 mr-1" />
            View Supported Formats
          </Button>
        </SheetTrigger>
        <SheetContent className="bg-gray-900 text-white border-white/10">
          <SheetHeader>
            <SheetTitle className="text-white">Supported CSV Formats</SheetTitle>
            <SheetDescription className="text-white/70">
              The system will automatically detect and map columns from various formats.
            </SheetDescription>
          </SheetHeader>
          <div className="mt-6 space-y-4">
            <div>
              <h3 className="font-medium text-white mb-2">Standard Format</h3>
              <pre className="bg-black/30 p-3 rounded overflow-auto text-xs">
                id,sender,receiver,amount,timestamp<br />
                tx123,0x8a23b2,0x9c45d1,25.5,2023-04-15 12:30:00
              </pre>
            </div>
            <div>
              <h3 className="font-medium text-white mb-2">Elliptic Format</h3>
              <pre className="bg-black/30 p-3 rounded overflow-auto text-xs">
                {sampleCsvContent}
              </pre>
            </div>
            <div className="space-y-2 text-sm">
              <p>The system will try to automatically map:</p>
              <ul className="list-disc pl-5 space-y-1">
                <li><span className="text-quantum-cyan">Transaction IDs:</span> txid, hash, id, etc.</li>
                <li><span className="text-quantum-cyan">Source addresses:</span> sender, from, source, input, etc.</li>
                <li><span className="text-quantum-cyan">Target addresses:</span> receiver, to, target, destination, etc.</li>
                <li><span className="text-quantum-cyan">Transaction amounts:</span> amount, value, btc, etc.</li>
                <li><span className="text-quantum-cyan">Risk classification:</span> class, category, label, etc.</li>
              </ul>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default FormatInfo;
