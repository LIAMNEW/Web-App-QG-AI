
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, TrendingUp, AlertTriangle, Shield, Download } from 'lucide-react';
import { useTransactionStore } from '@/stores/transactionStore';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';

const ReportsSection: React.FC = () => {
  const { transactions } = useTransactionStore();
  const { toast } = useToast();

  // Calculate statistics
  const totalTransactions = transactions.length;
  const highRiskCount = transactions.filter(tx => tx.riskScore === 'high').length;
  const mediumRiskCount = transactions.filter(tx => tx.riskScore === 'medium').length;
  const lowRiskCount = transactions.filter(tx => tx.riskScore === 'low').length;
  const suspiciousCount = transactions.filter(tx => tx.status === 'suspicious').length;

  const fraudRate = totalTransactions > 0 ? ((suspiciousCount / totalTransactions) * 100).toFixed(1) : '0';

  const handleQuickExport = (riskLevel: string) => {
    if (totalTransactions === 0) {
      toast({
        variant: "destructive",
        title: "No data available",
        description: "Please upload transaction data first."
      });
      return;
    }

    const filteredTransactions = riskLevel === 'all' 
      ? transactions 
      : transactions.filter(tx => tx.riskScore === riskLevel);

    const headers = ['Transaction ID', 'Sender', 'Receiver', 'Amount', 'Timestamp', 'Status', 'Risk Score'];
    const csvContent = [
      headers.join(','),
      ...filteredTransactions.map(tx => [
        tx.id,
        tx.sender,
        tx.receiver,
        tx.amount,
        tx.timestamp,
        tx.status,
        tx.riskScore
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${riskLevel}-risk-transactions-${new Date().toISOString().slice(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({
      title: "Report exported",
      description: `${filteredTransactions.length} ${riskLevel} risk transactions exported.`
    });
  };

  if (totalTransactions === 0) {
    return (
      <Card className="bg-white/5 border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Transaction Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-white/70 text-center py-4">
            Upload transaction data to view reports and analytics
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Transaction Reports & Analytics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Statistics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-white">{totalTransactions}</div>
            <div className="text-white/70 text-sm">Total Transactions</div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-red-400">{highRiskCount}</div>
            <div className="text-white/70 text-sm">High Risk</div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-yellow-400">{mediumRiskCount}</div>
            <div className="text-white/70 text-sm">Medium Risk</div>
          </div>
          <div className="bg-white/5 rounded-lg p-3 text-center">
            <div className="text-2xl font-bold text-green-400">{lowRiskCount}</div>
            <div className="text-white/70 text-sm">Low Risk</div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex items-center gap-3 bg-white/5 rounded-lg p-4">
            <AlertTriangle className="h-8 w-8 text-red-400" />
            <div>
              <div className="text-xl font-bold text-white">{fraudRate}%</div>
              <div className="text-white/70 text-sm">Fraud Detection Rate</div>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-white/5 rounded-lg p-4">
            <Shield className="h-8 w-8 text-quantum-cyan" />
            <div>
              <div className="text-xl font-bold text-white">{suspiciousCount}</div>
              <div className="text-white/70 text-sm">Suspicious Transactions</div>
            </div>
          </div>
          <div className="flex items-center gap-3 bg-white/5 rounded-lg p-4">
            <TrendingUp className="h-8 w-8 text-green-400" />
            <div>
              <div className="text-xl font-bold text-white">{((lowRiskCount / totalTransactions) * 100).toFixed(1)}%</div>
              <div className="text-white/70 text-sm">Safe Transactions</div>
            </div>
          </div>
        </div>

        {/* Quick Export Options */}
        <div className="space-y-3">
          <h4 className="text-white font-medium">Quick Export Options</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Button 
              onClick={() => handleQuickExport('all')}
              variant="outline" 
              size="sm"
              className="hover:bg-quantum-cyan/20"
            >
              <Download className="h-3 w-3 mr-1" />
              All Data
            </Button>
            <Button 
              onClick={() => handleQuickExport('high')}
              variant="outline" 
              size="sm"
              className="hover:bg-red-500/20 text-red-400 border-red-400/30"
            >
              <Download className="h-3 w-3 mr-1" />
              High Risk
            </Button>
            <Button 
              onClick={() => handleQuickExport('medium')}
              variant="outline" 
              size="sm"
              className="hover:bg-yellow-500/20 text-yellow-400 border-yellow-400/30"
            >
              <Download className="h-3 w-3 mr-1" />
              Medium Risk
            </Button>
            <Button 
              onClick={() => handleQuickExport('low')}
              variant="outline" 
              size="sm"
              className="hover:bg-green-500/20 text-green-400 border-green-400/30"
            >
              <Download className="h-3 w-3 mr-1" />
              Low Risk
            </Button>
          </div>
        </div>

        {/* Advanced Reports Link */}
        <div className="pt-4 border-t border-white/10">
          <Link to="/reports">
            <Button className="w-full bg-quantum-cyan hover:bg-quantum-cyan/90">
              <FileText className="h-4 w-4 mr-2" />
              Advanced Reports & Analytics
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReportsSection;
