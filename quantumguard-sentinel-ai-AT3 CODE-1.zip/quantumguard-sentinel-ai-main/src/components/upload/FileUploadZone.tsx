
import React, { useRef } from 'react';
import { Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import SampleDataDownload from './SampleDataDownload';

interface FileUploadZoneProps {
  isDragging: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
  onFileSelect: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const FileUploadZone: React.FC<FileUploadZoneProps> = ({
  isDragging,
  onDragOver,
  onDragLeave,
  onDrop,
  onFileSelect,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const triggerFileInput = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div
      className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
        isDragging ? 'border-quantum-cyan bg-quantum-cyan/10' : 'border-white/10'
      }`}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={onDrop}
    >
      <Upload className="h-12 w-12 mx-auto mb-4 text-white/70" />
      <p className="text-white/90 mb-2">
        Drag and drop your CSV file here, or
      </p>
      <Button 
        onClick={triggerFileInput}
        variant="outline" 
        className="hover:bg-quantum-cyan/20"
      >
        Browse Files
      </Button>
      <input
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept=".csv"
        onChange={onFileSelect}
      />
      <div className="mt-4 pt-4 border-t border-white/10">
        <p className="text-sm text-white/70">Need sample data?</p>
        <SampleDataDownload />
      </div>
    </div>
  );
};

export default FileUploadZone;
