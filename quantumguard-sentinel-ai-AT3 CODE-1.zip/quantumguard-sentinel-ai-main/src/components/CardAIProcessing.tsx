
import React from 'react';
import { Button } from '@/components/ui/button';
import { Play } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Database } from '@/integrations/supabase/types';

// Use the types from the generated Supabase types file
type CardData = Database['public']['Tables']['Card1_Data']['Row'];

export function CardAIProcessing() {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [progress, setProgress] = React.useState(0);
  const navigate = useNavigate();

  const processCardWithAI = async (card: CardData) => {
    try {
      // Prepare card data for analysis
      const { data, error } = await supabase.functions.invoke('analyze-card-data', {
        body: {
          card_details: {
            card_number: card.card_number,
            cvv: card.cvv,
            card_type: card.card_type,
            card_brand: card.card_brand,
            expires: card.expires,
            has_chip: card.has_chip,
            num_cards_issued: card.num_cards_issued,
            year_pin_last_changed: card.year_pin_last_changed,
            card_on_dark_web: card.card_on_dark_web,
            acct_open_date: card.acct_open_date,
            credit_limit: card.credit_limit
          }
        }
      });

      if (error) throw error;

      // Now using the properly typed update operation with the Supabase types
      const { error: updateError } = await supabase
        .from('Card1_Data')
        .update({
          risk_score: data.riskScore,
          explanation: data.explanation
        })
        .eq('id', card.id);

      if (updateError) throw updateError;

      return {
        ...card,
        risk_score: data.riskScore,
        explanation: data.explanation
      };
    } catch (error) {
      console.error('Error processing card data:', error);
      return false;
    }
  };

  const handleBulkProcess = async () => {
    if (isProcessing) return;
    
    setIsProcessing(true);
    setProgress(0);
    let processed = 0;
    let failed = 0;
    let updatedCards = [];

    try {
      const { data: unprocessedCards, error } = await supabase
        .from('Card1_Data')
        .select('*')
        .is('risk_score', null)
        .order('id', { ascending: true });

      if (error) throw error;

      if (!unprocessedCards?.length) {
        toast({
          title: "No card data to process",
          description: "All card data has already been analyzed."
        });
        setIsProcessing(false);
        return;
      }

      toast({
        title: "Starting card data analysis",
        description: `Processing ${unprocessedCards.length} card records...`
      });

      const totalCards = unprocessedCards.length;
      const batchSize = 10; // Process in smaller batches for card data

      for (let i = 0; i < totalCards; i += batchSize) {
        const batch = unprocessedCards.slice(i, i + batchSize);
        const batchResults = [];
        
        for (const card of batch) {
          const result = await processCardWithAI(card as CardData);
          if (result) {
            processed++;
            batchResults.push(result);
          } else {
            failed++;
          }

          // Update progress and notify
          const currentProgress = (i + batch.indexOf(card) + 1) / totalCards;
          setProgress(Math.round(currentProgress * 100));
          
          if (processed % 5 === 0 || processed + failed === totalCards) {
            toast({
              title: "Processing card data",
              description: `Processed ${processed} of ${totalCards} cards (${failed} failed)`
            });
          }
        }
        
        updatedCards.push(...batchResults);
      }

      toast({
        title: "Card data analysis complete",
        description: `Successfully processed ${processed} cards. ${failed ? `Failed: ${failed}` : ''}`
      });
    } catch (error) {
      console.error('Error in bulk card processing:', error);
      toast({
        variant: "destructive",
        title: "Processing failed",
        description: "An error occurred while processing card data."
      });
    } finally {
      setIsProcessing(false);
      setTimeout(() => {
        // Refresh data
        navigate(0);
      }, 1000);
    }
  };

  return (
    <Button 
      onClick={handleBulkProcess} 
      disabled={isProcessing}
      className="mb-4 bg-red-600 hover:bg-red-700"
    >
      <Play className="mr-2 h-4 w-4" />
      {isProcessing ? `Processing Cards... ${progress}%` : 'Run Card AI Analysis'}
    </Button>
  );
}
