
import React, { useState } from 'react';
import { Shield, Database, Upload, LogOut, User, Settings, Activity, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface NavLinkProps {
  href: string;
  icon: React.ReactNode;
  text: string;
  active?: boolean;
  onClick?: () => void;
}

const NavLink: React.FC<NavLinkProps> = ({ href, icon, text, active, onClick }) => (
  <Link
    to={href}
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 px-4 py-3 rounded-md transition-all text-base",
      active 
        ? "bg-quantum-cyan/10 text-quantum-cyan font-medium" 
        : "text-white/70 hover:text-white hover:bg-white/5"
    )}
  >
    {icon}
    <span>{text}</span>
  </Link>
);

const Header: React.FC = () => {
  const { user, signOut } = useAuth();
  const isAuthenticated = !!user;
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const getUserInitials = () => {
    if (!user || !user.email) return 'U';
    return user.email.substring(0, 1).toUpperCase();
  };

  const closeMobileMenu = () => setMobileMenuOpen(false);

  const navItems = [
    {
      href: "/",
      icon: <Database className="h-5 w-5" />,
      text: "Dashboard",
      active: window.location.pathname === '/'
    },
    {
      href: "/upload",
      icon: <Upload className="h-5 w-5" />,
      text: "Upload Transactions",
      active: window.location.pathname === '/upload'
    },
    {
      href: "/admin",
      icon: <Settings className="h-5 w-5" />,
      text: "Admin Console",
      active: window.location.pathname === '/admin'
    },
    {
      href: "#",
      icon: <Activity className="h-5 w-5" />,
      text: "Analytics"
    }
  ];

  return (
    <header className="w-full bg-quantum-navy/95 backdrop-blur-sm border-b border-white/10 py-3 px-4 lg:px-8 fixed top-0 z-50">
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-2">
          <Link to="/">
            <Shield className="h-8 w-8 text-quantum-cyan" />
          </Link>
          <div className="flex flex-col">
            <span className="font-bold text-lg text-white">QuantumGuard</span>
            <span className="text-quantum-cyan text-xs font-medium -mt-1">SENTINEL AI</span>
          </div>
        </div>
        
        {/* Desktop Navigation */}
        {isAuthenticated && (
          <nav className="hidden lg:flex space-x-1">
            {navItems.map((item) => (
              <NavLink 
                key={item.href}
                href={item.href} 
                icon={React.cloneElement(item.icon as React.ReactElement, { className: "h-4 w-4" })}
                text={item.text} 
                active={item.active}
              />
            ))}
          </nav>
        )}
        
        {/* Right side actions */}
        <div className="flex items-center space-x-2">
          {isAuthenticated ? (
            <>
              {/* Status indicator - hidden on small screens */}
              <div className="hidden sm:flex items-center">
                <div className="h-2 w-2 rounded-full bg-quantum-success animate-pulse mr-2"></div>
                <span className="text-sm text-white/80">System Secure</span>
              </div>
              
              {/* Mobile Menu */}
              {isAuthenticated && (
                <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="lg:hidden">
                      <Menu className="h-5 w-5 text-white" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="bg-quantum-navy border-white/10 w-80">
                    <div className="flex flex-col h-full">
                      <div className="flex items-center space-x-2 p-4 border-b border-white/10">
                        <Shield className="h-6 w-6 text-quantum-cyan" />
                        <div>
                          <span className="font-bold text-white">QuantumGuard</span>
                          <div className="text-quantum-cyan text-xs">SENTINEL AI</div>
                        </div>
                      </div>
                      
                      <nav className="flex-1 py-4">
                        <div className="space-y-1">
                          {navItems.map((item) => (
                            <NavLink 
                              key={item.href}
                              href={item.href} 
                              icon={item.icon}
                              text={item.text} 
                              active={item.active}
                              onClick={closeMobileMenu}
                            />
                          ))}
                        </div>
                      </nav>
                      
                      <div className="border-t border-white/10 p-4">
                        <div className="flex items-center space-x-3 mb-4">
                          <Avatar className="h-10 w-10 bg-quantum-cyan/20">
                            <AvatarFallback className="bg-transparent text-quantum-cyan">
                              {getUserInitials()}
                            </AvatarFallback>
                          </Avatar>
                          <div className="text-white/80 text-sm">
                            {user?.email}
                          </div>
                        </div>
                        <Button 
                          onClick={() => {
                            closeMobileMenu();
                            signOut();
                          }}
                          variant="outline" 
                          className="w-full border-white/20 text-white hover:bg-white/5"
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          Sign Out
                        </Button>
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              )}
              
              {/* Desktop User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full">
                    <Avatar className="h-8 w-8 bg-quantum-cyan/20 hover:bg-quantum-cyan/30 transition-colors">
                      <AvatarFallback className="bg-transparent text-quantum-cyan">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-quantum-navy border-white/10">
                  <DropdownMenuItem className="text-white/80 cursor-pointer hover:bg-white/5 hover:text-white flex items-center gap-2">
                    <User className="h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-white/80 cursor-pointer hover:bg-white/5 hover:text-white flex items-center gap-2">
                    <Settings className="h-4 w-4" />
                    <span>
                      <Link to="/admin">Admin Console</Link>
                    </span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator className="bg-white/10" />
                  <DropdownMenuItem 
                    className="text-white/80 cursor-pointer hover:bg-white/5 hover:text-white flex items-center gap-2"
                    onClick={() => signOut()}
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Sign Out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <Link to="/auth">
              <Button className="bg-quantum-cyan hover:bg-quantum-cyan/90 text-quantum-dark">
                Sign In
              </Button>
            </Link>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
