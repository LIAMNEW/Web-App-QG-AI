
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { useDynamicAnalytics } from './DynamicAnalytics';

const RiskScoreCard: React.FC = () => {
  const { riskScore, riskLevel, alerts, fraudCount, totalTransactions } = useDynamicAnalytics();

  const getColorClass = () => {
    switch (riskLevel) {
      case 'low': return 'text-quantum-success';
      case 'medium': return 'text-quantum-warning';
      case 'high': return 'text-quantum-alert';
      case 'critical': return 'text-red-500';
      default: return 'text-quantum-cyan';
    }
  };
  
  const getProgressColor = () => {
    switch (riskLevel) {
      case 'low': return 'bg-quantum-success';
      case 'medium': return 'bg-quantum-warning';
      case 'high': return 'bg-quantum-alert';
      case 'critical': return 'bg-red-500';
      default: return 'bg-quantum-cyan';
    }
  };

  return (
    <Card className="bg-white/5 border-white/10 text-white hover:bg-white/10 transition-colors">
      <CardHeader className="pb-2">
        <CardTitle className="text-white/90 flex items-center text-lg">
          <AlertTriangle className="h-5 w-5 mr-2 text-quantum-warning" />
          Network Risk Score
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-end justify-between mb-2">
          <div className="text-4xl font-bold tracking-tight">
            <span className={getColorClass()}>{riskScore}</span>
            <span className="text-lg text-white/50 ml-1">/100</span>
          </div>
          <div className="text-right">
            <span className={`text-sm font-medium ${getColorClass()} uppercase`}>
              {riskLevel}
            </span>
            <p className="text-xs text-white/70">Risk Level</p>
          </div>
        </div>
        
        <Progress value={riskScore} max={100} className="h-2 bg-white/10">
          <div className={`h-full ${getProgressColor()}`} style={{ width: `${riskScore}%` }} />
        </Progress>
        
        <div className="mt-4 pt-3 border-t border-white/10 flex justify-between items-center">
          <div>
            <p className="text-xs text-white/70">Active Alerts</p>
            <p className="text-lg font-medium">{alerts}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-white/70">
              {fraudCount}/{totalTransactions} Fraud
            </p>
            <p className="text-sm">Updated now</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RiskScoreCard;
