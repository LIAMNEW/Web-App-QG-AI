
import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle } from 'lucide-react';
import { useTransactionStore } from '@/stores/transactionStore';

const TransactionList: React.FC = () => {
  const { transactions } = useTransactionStore();
  
  // Use sample transactions if no data has been uploaded
  const displayTransactions = transactions.length > 0 
    ? transactions.slice(0, 10)  // Show maximum 10 rows
    : [
        {
          id: 'tx-8971',
          sender: '0x7Fc9...3b54',
          receiver: '0x3aF1...9c23',
          amount: '12.45 ETH',
          timestamp: '2025-04-07 12:34:21',
          status: 'successful',
          riskScore: 'low',
        },
        {
          id: 'tx-8972',
          sender: '0x2bA3...7e11',
          receiver: '0x9Df2...4a97',
          amount: '0.78 ETH',
          timestamp: '2025-04-07 12:33:15',
          status: 'successful',
          riskScore: 'low',
        },
        {
          id: 'tx-8973',
          sender: '0x5cC7...2f68',
          receiver: '0x1Ee8...8b12',
          amount: '145.00 ETH',
          timestamp: '2025-04-07 12:31:52',
          status: 'suspicious',
          riskScore: 'high',
        },
        {
          id: 'tx-8974',
          sender: '0x4dD2...6a33',
          receiver: '0x8Bc5...3f47',
          amount: '3.21 ETH',
          timestamp: '2025-04-07 12:30:09',
          status: 'successful',
          riskScore: 'low',
        },
        {
          id: 'tx-8975',
          sender: '0x3fF1...9e74',
          receiver: '0x7aC3...2b18',
          amount: '28.50 ETH',
          timestamp: '2025-04-07 12:28:44',
          status: 'successful',
          riskScore: 'medium',
        }
      ];

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead className="text-white/70">Transaction ID</TableHead>
            <TableHead className="text-white/70">Sender</TableHead>
            <TableHead className="text-white/70">Receiver</TableHead>
            <TableHead className="text-white/70">Amount</TableHead>
            <TableHead className="text-white/70">Timestamp</TableHead>
            <TableHead className="text-white/70">Status</TableHead>
            <TableHead className="text-white/70">Risk Score</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {displayTransactions.map((tx) => (
            <TableRow key={tx.id} className="border-white/10">
              <TableCell className="font-mono text-quantum-cyan">{tx.id}</TableCell>
              <TableCell className="font-mono">{tx.sender}</TableCell>
              <TableCell className="font-mono">{tx.receiver}</TableCell>
              <TableCell>{tx.amount}</TableCell>
              <TableCell>{tx.timestamp}</TableCell>
              <TableCell>
                {tx.status === 'successful' ? (
                  <Badge className="bg-quantum-success/20 text-quantum-success border-quantum-success/20 flex items-center gap-1">
                    <CheckCircle className="h-3 w-3" />
                    Successful
                  </Badge>
                ) : (
                  <Badge className="bg-quantum-alert/20 text-quantum-alert border-quantum-alert/20 flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    Suspicious
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                {tx.riskScore === 'low' && (
                  <Badge className="bg-quantum-success/20 text-quantum-success border-quantum-success/20">
                    Low
                  </Badge>
                )}
                {tx.riskScore === 'medium' && (
                  <Badge className="bg-quantum-warning/20 text-quantum-warning border-quantum-warning/20">
                    Medium
                  </Badge>
                )}
                {tx.riskScore === 'high' && (
                  <Badge className="bg-quantum-alert/20 text-quantum-alert border-quantum-alert/20">
                    High
                  </Badge>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};

export default TransactionList;
