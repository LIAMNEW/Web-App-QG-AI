
import React from 'react';
import { Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Hero: React.FC = () => {
  return (
    <section className="min-h-[80vh] relative overflow-hidden bg-quantum-navy bg-cyber-pattern flex flex-col items-center justify-center py-20 px-4">
      <div className="absolute inset-0 bg-gradient-to-b from-quantum-navy/90 to-quantum-navy"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        <div className="inline-flex items-center justify-center p-4 mb-6 bg-white/5 backdrop-blur-xl rounded-full border border-white/10">
          <Shield className="h-10 w-10 text-quantum-cyan animate-pulse-slow" />
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
          <span className="block">Quantum-Resilient</span>
          <span className="text-quantum-cyan glow-text">AI-Powered</span>
          <span className="block">Blockchain Security</span>
        </h1>
        
        <p className="text-lg md:text-xl text-white/80 mb-8 max-w-3xl mx-auto">
          QuantumGuard Sentinel AI detects fraud in real-time across blockchain networks, 
          ensuring compliance with financial regulations while preparing for 
          quantum computing challenges.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
          <Button className="bg-quantum-cyan hover:bg-quantum-cyan/90 text-quantum-navy font-medium px-8 py-6 text-lg">
            Explore Dashboard
          </Button>
          <Button variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8 py-6 text-lg">
            Learn More
          </Button>
        </div>
        
        <div className="mt-16 flex flex-wrap justify-center gap-6 text-white/60">
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-quantum-success mr-2"></div>
            <span>AI-Powered Detection</span>
          </div>
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-quantum-cyan mr-2"></div>
            <span>Quantum-Resilient</span>
          </div>
          <div className="flex items-center">
            <div className="h-2 w-2 rounded-full bg-quantum-warning mr-2"></div>
            <span>Real-Time Monitoring</span>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-quantum-dark to-transparent"></div>
    </section>
  );
};

export default Hero;
