
import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield } from 'lucide-react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';

const UserProfile: React.FC = () => {
  const { user } = useAuth();
  
  const getUserInitials = () => {
    if (!user || !user.email) return 'U';
    return user.email.substring(0, 1).toUpperCase();
  };

  return (
    <Card className="bg-white/5 border-white/10 text-white">
      <CardHeader className="pb-2">
        <CardTitle className="text-white/90 flex items-center">
          <Shield className="h-5 w-5 mr-2 text-quantum-cyan" />
          Analyst Profile
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center space-x-4">
          <Avatar className="h-16 w-16 bg-quantum-cyan/20 border border-quantum-cyan/30">
            <AvatarFallback className="bg-transparent text-quantum-cyan text-xl">
              {getUserInitials()}
            </AvatarFallback>
          </Avatar>
          <div>
            <h3 className="text-lg font-medium">{user?.email || 'Analyst'}</h3>
            <p className="text-sm text-white/70">Security Analyst</p>
            <div className="flex items-center mt-2">
              <div className="h-2 w-2 rounded-full bg-quantum-success mr-2"></div>
              <span className="text-xs text-white/70">Online · Clearance Level 3</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UserProfile;
