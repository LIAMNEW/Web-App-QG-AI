
import React from 'react';
import RiskScoreCard from './RiskScoreCard';
import AnalyticsChart from './AnalyticsChart';
import { TransactionAnalysis } from './TransactionAnalysis';
import { CardDataAnalysis } from './CardDataAnalysis';
import UserProfile from './UserProfile';
import SmartSearch from './SmartSearch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Dashboard: React.FC = () => {
  return (
    <section className="py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl md:text-3xl font-bold text-white">Blockchain Security Dashboard</h2>
          <p className="text-white/70">Real-time monitoring and quantum-resilient security</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <RiskScoreCard />
          <div className="lg:col-span-2">
            <AnalyticsChart />
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="space-y-6">
            <UserProfile />
            <SmartSearch />
          </div>
          <div className="lg:col-span-2">
            <div className="bg-white/5 border border-white/10 rounded-lg p-4">
              <h3 className="text-lg font-medium text-white mb-4">Data Analysis</h3>
              
              <Tabs defaultValue="transactions" className="mb-6">
                <TabsList className="mb-4">
                  <TabsTrigger value="transactions">Transactions</TabsTrigger>
                  <TabsTrigger value="cards">Card Data</TabsTrigger>
                </TabsList>
                
                <TabsContent value="transactions">
                  <TransactionAnalysis />
                </TabsContent>
                
                <TabsContent value="cards">
                  <CardDataAnalysis />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;
