
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

interface ProtectedRouteProps {
  children?: React.ReactNode;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children }) => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) {
    // Show loading state while checking auth
    return (
      <div className="min-h-screen bg-quantum-dark flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-quantum-cyan"></div>
      </div>
    );
  }
  
  if (!user) {
    // Redirect to auth page if not logged in
    return <Navigate to="/auth" replace />;
  }

  // Render children or outlet if authenticated
  return children ? <>{children}</> : <Outlet />;
};

export default ProtectedRoute;
