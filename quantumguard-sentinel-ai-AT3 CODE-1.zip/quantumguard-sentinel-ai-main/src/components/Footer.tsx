
import React from 'react';
import { Shield } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-quantum-navy py-12 px-4 lg:px-8 border-t border-white/10">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center mb-4 md:mb-0">
            <Shield className="h-8 w-8 text-quantum-cyan mr-2" />
            <div>
              <div className="text-xl font-bold text-white">QuantumGuard</div>
              <div className="text-xs text-quantum-cyan">SENTINEL AI</div>
            </div>
          </div>
          
          <div className="flex space-x-6">
            <a href="#" className="text-white/70 hover:text-quantum-cyan">
              Documentation
            </a>
            <a href="#" className="text-white/70 hover:text-quantum-cyan">
              About
            </a>
            <a href="#" className="text-white/70 hover:text-quantum-cyan">
              Contact
            </a>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
          <div className="text-white/50 mb-4 md:mb-0">
            © 2025 QuantumGuard Sentinel AI. All rights reserved.
          </div>
          <div className="text-white/50">
            Quantum-resilient blockchain security
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
