
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { AlertCircle, Loader2 } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CardAIProcessing } from "./CardAIProcessing";
import { Database } from "@/integrations/supabase/types";

// Use the types from the generated Supabase types file for consistency
type CardData = Database['public']['Tables']['Card1_Data']['Row'];

export function CardDataAnalysis() {
  // Fetch card data with React Query
  const { data: cardData, error, isLoading } = useQuery({
    queryKey: ["card-data"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("Card1_Data")
        .select("*")
        .order("id", { ascending: true })
        .limit(100);
      
      if (error) throw error;
      return data as CardData[];
    },
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-quantum-cyan" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>Error loading card data: {error.message}</AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border border-white/10">
      <div className="p-4 border-b border-white/10">
        <CardAIProcessing />
      </div>
      <Table>
        <TableHeader>
          <TableRow className="border-white/10">
            <TableHead>ID</TableHead>
            <TableHead>Card Brand</TableHead>
            <TableHead>Card Type</TableHead>
            <TableHead>Has Chip</TableHead>
            <TableHead>Cards Issued</TableHead>
            <TableHead>PIN Changed</TableHead>
            <TableHead>Dark Web</TableHead>
            <TableHead>Risk Score</TableHead>
            <TableHead>Explanation</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {cardData?.map((card) => (
            <TableRow key={card.id} className="border-white/10">
              <TableCell className="font-mono">{card.id}</TableCell>
              <TableCell>{card.card_brand || 'Unknown'}</TableCell>
              <TableCell>{card.card_type || 'Unknown'}</TableCell>
              <TableCell>{card.has_chip || 'Unknown'}</TableCell>
              <TableCell>{card.num_cards_issued || 'Unknown'}</TableCell>
              <TableCell>{card.year_pin_last_changed || 'Unknown'}</TableCell>
              <TableCell>{card.card_on_dark_web || 'Unknown'}</TableCell>
              <TableCell>
                {card.risk_score !== null ? Number(card.risk_score).toFixed(4) : 'Pending'}
              </TableCell>
              <TableCell className="max-w-md truncate">
                {card.explanation || 'Pending analysis'}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
