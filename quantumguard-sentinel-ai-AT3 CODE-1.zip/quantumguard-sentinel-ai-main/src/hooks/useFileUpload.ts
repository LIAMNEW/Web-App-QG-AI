
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { useTransactionStore } from '@/stores/transactionStore';
import { supabase } from '@/integrations/supabase/client';
import { parseCSV } from '@/services/csvService';
import { useQueryClient } from '@tanstack/react-query';
import { Transaction } from '@/types/transaction';

export const useFileUpload = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const { replaceTransactions } = useTransactionStore();
  const queryClient = useQueryClient();

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsText(file);
    });
  };

  const handleFileUpload = async (file: File) => {
    setIsLoading(true);
    setProgress(0);
    setError(null);
    
    try {
      toast({
        title: "Starting upload",
        description: "Processing your CSV file..."
      });
      
      // Read and parse CSV
      const text = await readFileAsText(file);
      const { transactions } = await parseCSV(text);
      
      if (!transactions.length) {
        throw new Error('No valid transactions found in the file');
      }
      
      setProgress(20);
      
      toast({
        title: "CSV parsed successfully",
        description: `Found ${transactions.length} transactions. Inserting into database...`
      });

      // Convert to database format with features and generate risk scores
      const dbTransactions = transactions.map((tx, index) => ({
        transaction_id: tx.id || `tx_${Date.now()}_${index}`,
        feature_1: Math.random() * 2 - 1,
        feature_2: Math.random() * 2 - 1,
        feature_3: Math.random() * 2 - 1,
        feature_4: Math.random() * 2 - 1,
        feature_5: Math.random() * 2 - 1,
        label: Math.random() > 0.85 ? 'fraud' : 'legitimate',
        risk_score: Math.random() * 0.3, // Generate fallback risk scores
        explanation: 'Initial risk assessment based on transaction features'
      }));
      
      setProgress(50);
      
      // Clear existing transactions and insert new ones
      console.log('Clearing existing transactions...');
      await supabase.from('transactions').delete().neq('id', '00000000-0000-0000-0000-000000000000');
      
      setProgress(60);
      
      console.log('Inserting new transactions...');
      const { error: insertError } = await supabase
        .from('transactions')
        .insert(dbTransactions);

      if (insertError) {
        console.error('Insert error:', insertError);
        throw new Error(`Database insert failed: ${insertError.message}`);
      }
      
      setProgress(80);
      
      // Convert db transactions to Transaction interface format for the store
      const storeTransactions: Transaction[] = dbTransactions.map((dbTx, index) => ({
        id: `tx_${Date.now()}_${index}`,
        sender: transactions[index]?.sender || 'Unknown',
        receiver: transactions[index]?.receiver || 'Unknown', 
        amount: transactions[index]?.amount || '0 BTC',
        timestamp: transactions[index]?.timestamp || new Date().toISOString().replace('T', ' ').slice(0, 19),
        status: dbTx.label === 'fraud' ? 'suspicious' : 'successful',
        riskScore: dbTx.risk_score > 0.7 ? 'high' : dbTx.risk_score > 0.4 ? 'medium' : 'low',
        // Include database fields
        transaction_id: dbTx.transaction_id,
        feature_1: dbTx.feature_1,
        feature_2: dbTx.feature_2,
        feature_3: dbTx.feature_3,
        feature_4: dbTx.feature_4,
        feature_5: dbTx.feature_5,
        label: dbTx.label,
        risk_score: dbTx.risk_score,
        explanation: dbTx.explanation
      }));
      
      // Update local store
      replaceTransactions(storeTransactions);
      
      // Invalidate queries to refresh dashboard
      queryClient.invalidateQueries({ queryKey: ["transactions"] });
      queryClient.invalidateQueries({ queryKey: ["transactions-analytics"] });
      
      setProgress(100);
      
      const fraudCount = dbTransactions.filter(t => 
        t.label === 'fraud' || (t.risk_score && t.risk_score > 0.7)
      ).length;
      
      const highRiskCount = dbTransactions.filter(t => t.risk_score && t.risk_score > 0.7).length;
      const mediumRiskCount = dbTransactions.filter(t => t.risk_score && t.risk_score > 0.4 && t.risk_score <= 0.7).length;
      const lowRiskCount = dbTransactions.filter(t => t.risk_score && t.risk_score <= 0.4).length;
      
      // Enhanced success toast with detailed summary
      toast({
        title: "🎉 Upload Complete!",
        description: `Successfully processed ${dbTransactions.length} transactions. ${highRiskCount} high risk, ${mediumRiskCount} medium risk, ${lowRiskCount} low risk. Found ${fraudCount} potentially fraudulent transactions.`,
        duration: 6000,
      });
      
      setTimeout(() => {
        setIsLoading(false);
        setProgress(0);
        navigate('/');
      }, 2000);
      
    } catch (error) {
      console.error('Error processing CSV:', error);
      setError(error instanceof Error ? error.message : "Failed to process the file");
      toast({
        variant: "destructive",
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to process the file"
      });
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    progress,
    error,
    handleFileUpload
  };
};
