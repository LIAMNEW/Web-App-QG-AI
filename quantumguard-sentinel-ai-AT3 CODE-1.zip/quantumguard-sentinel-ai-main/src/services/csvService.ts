
import { Transaction } from '@/types/transaction';

export interface CSVParseResult {
  headers: string[];
  transactions: Transaction[];
}

/**
 * Parse CSV content and convert it to Transaction objects
 */
export const parseCSV = async (csvContent: string): Promise<CSVParseResult> => {
  // Split by lines
  const lines = csvContent.trim().split('\n');
  
  if (lines.length < 2) {
    throw new Error('CSV file is empty or invalid');
  }
  
  // Extract headers
  const headers = lines[0].split(',').map(header => header.trim());
  
  // Map CSV fields to our transaction properties - support more formats including Elliptic Bitcoin dataset
  const fieldMap = {
    // Common transaction identifiers
    id: headers.findIndex(h => /id|txid|hash|transaction[\s_-]?id|tx[\s_-]?hash/i.test(h)),
    
    // Address fields with different naming conventions
    sender: headers.findIndex(h => /sender|from|source|input|src|address[\s_-]?from|source[\s_-]?address|txfrom/i.test(h)),
    receiver: headers.findIndex(h => /receiver|to|recipient|destination|output|dst|address[\s_-]?to|target[\s_-]?address|txto/i.test(h)),
    
    // Value fields
    amount: headers.findIndex(h => /amount|value|btc|bitcoin|eth|sum|total|quantity/i.test(h)),
    
    // Time fields
    timestamp: headers.findIndex(h => /timestamp|date|time|block[\s_-]?time|created[\s_-]?at/i.test(h)),
    
    // Elliptic specific fields
    class: headers.findIndex(h => /class|category|classification|label/i.test(h)),
    
    // Extra fields for risk analysis
    transactionType: headers.findIndex(h => /type|tx[\s_-]?type/i.test(h)),
    transactionFee: headers.findIndex(h => /fee|tx[\s_-]?fee/i.test(h)),
  };
  
  // For Elliptic dataset, we might need special handling for address fields
  let hasMappableColumns = true;
  
  // Check if we have basic fields required for transactions or can map them
  if (fieldMap.sender === -1 && fieldMap.receiver === -1) {
    // Try to find numeric columns that might contain addresses in Elliptic dataset
    // Elliptic often uses patterns like "txId1", "txId2" or numbered columns
    const potentialSourceColumns = headers.findIndex(h => /1|input|in|source/i.test(h));
    const potentialDestColumns = headers.findIndex(h => /2|output|out|target/i.test(h));
    
    if (potentialSourceColumns !== -1) fieldMap.sender = potentialSourceColumns;
    if (potentialDestColumns !== -1) fieldMap.receiver = potentialDestColumns;
  }
  
  // If we still don't have sender/receiver, look for columns that might contain them
  if (fieldMap.sender === -1 && fieldMap.receiver === -1) {
    // Check for any column that might contain address-like patterns
    headers.forEach((header, index) => {
      if (/address|tx|node/i.test(header)) {
        if (fieldMap.sender === -1) fieldMap.sender = index;
        else if (fieldMap.receiver === -1) fieldMap.receiver = index;
      }
    });
  }
  
  // If we can't find amount, try to find any numeric column
  if (fieldMap.amount === -1) {
    // Look for weight, feature, etc.
    fieldMap.amount = headers.findIndex(h => /weight|feature|count|value/i.test(h));
  }
  
  // If we still can't map required fields, try to use first few columns as fallbacks
  if (fieldMap.sender === -1 && headers.length > 0) fieldMap.sender = 0;
  if (fieldMap.receiver === -1 && headers.length > 1) fieldMap.receiver = 1;
  if (fieldMap.amount === -1 && headers.length > 2) fieldMap.amount = 2;
  if (fieldMap.id === -1 && headers.length > 0) fieldMap.id = 0;
  
  // Process each line (skip header)
  const transactions: Transaction[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    // Skip empty lines
    if (!lines[i].trim()) continue;
    
    const values = lines[i].split(',').map(val => val.trim());
    
    // Determine risk score
    // If Elliptic dataset has a class column, use it (commonly 1=illicit, 2=licit, etc.)
    let riskScore: 'low' | 'medium' | 'high' = 'low';
    
    if (fieldMap.class !== -1) {
      const classValue = values[fieldMap.class];
      // In Elliptic dataset, class "1" often means illicit (high risk)
      if (classValue === "1" || classValue.toLowerCase() === "illicit") {
        riskScore = 'high';
      } else if (classValue === "unknown" || classValue === "2") {
        riskScore = 'medium';
      }
    } else {
      // Fallback to amount-based scoring
      const amount = parseFloat(values[fieldMap.amount]) || 0;
      if (amount > 100) {
        riskScore = 'high';
      } else if (amount > 50) {
        riskScore = 'medium';
      }
    }
    
    // Generate a transaction ID if not present
    const id = fieldMap.id !== -1 && values[fieldMap.id] 
      ? values[fieldMap.id] 
      : `tx-${Math.floor(Math.random() * 10000)}`;
    
    // Use data from CSV or placeholders
    const transaction: Transaction = {
      id,
      sender: fieldMap.sender !== -1 && values[fieldMap.sender] ? values[fieldMap.sender] : 'Unknown',
      receiver: fieldMap.receiver !== -1 && values[fieldMap.receiver] ? values[fieldMap.receiver] : 'Unknown',
      amount: fieldMap.amount !== -1 ? `${values[fieldMap.amount]} BTC` : '0 BTC',
      timestamp: fieldMap.timestamp !== -1 
        ? values[fieldMap.timestamp] 
        : new Date().toISOString().replace('T', ' ').slice(0, 19),
      status: riskScore === 'high' ? 'suspicious' : 'successful',
      riskScore,
    };
    
    transactions.push(transaction);
  }
  
  if (transactions.length === 0) {
    throw new Error('No valid transactions could be extracted from the CSV. Please check the file format.');
  }
  
  return {
    headers,
    transactions,
  };
};
