
// This is a configuration file you can use with your tailwind.config.js to include the custom colors
module.exports = {
  theme: {
    extend: {
      colors: {
        quantum: {
          dark: '#101420', // Dark background
          navy: '#151a2c', // Slightly lighter dark background
          cyan: '#38bdf8', // Primary accent color
          success: '#4ade80', // Success color
          warning: '#facc15', // Warning color
          alert: '#f87171', // Alert/error color
        }
      }
    }
  }
};
