
# QuantumGuard AI Dashboard UI Implementation

This repository contains the code to implement the QuantumGuard AI blockchain security dashboard UI.

## Files

- `src/QuantumGuardDashboard.tsx`: The main dashboard component that includes all UI elements
- `src/tailwind.config.extended.js`: Extended Tailwind configuration with custom colors

## Installation Instructions

1. Make sure you have Tailwind CSS, React, and all required dependencies installed.

2. Add the custom colors to your Tailwind configuration by merging the contents of `tailwind.config.extended.js` into your existing `tailwind.config.js` file.

3. Install required dependencies:
   ```
   npm install recharts lucide-react @tanstack/react-query
   ```

4. Copy the `QuantumGuardDashboard.tsx` file to your project's components directory.

5. Import and use the dashboard component:
   ```jsx
   import QuantumGuardDashboard from './path/to/QuantumGuardDashboard';

   function App() {
     return (
       <div className="App">
         <QuantumGuardDashboard />
       </div>
     );
   }
   ```

## Features

The dashboard includes:

- Risk score visualization
- Transaction analytics chart
- User profile display
- AI-powered search capability
- Transaction data analysis
- Card security analysis
- Recent transactions list
- Security recommendations
- System monitoring status

## Customization

You can customize the dashboard by:

1. Modifying the sample data in the component
2. Adjusting the colors in the Tailwind configuration
3. Adding or removing sections as needed

## Requirements

- React 18+
- Tailwind CSS 3+
- Recharts
- Lucide React (for icons)
- TanStack Query (formerly React Query)

## Note

This is a UI implementation only. To make it fully functional, you'll need to:

1. Connect to real data sources
2. Implement the backend functionality for AI analysis
3. Set up authentication and user management
4. Configure real-time data updates
