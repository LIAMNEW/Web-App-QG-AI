
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const openAiApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAiApiKey) {
      throw new Error('OpenAI API key not found');
    }

    const { query, contextData } = await req.json();

    if (!query) {
      throw new Error('Query is required');
    }

    // If there are API quota issues, provide a direct answer using simple logic
    try {
      // Create prompt using the context data
      const systemPrompt = `
        You are a blockchain transaction analysis assistant. You help users search through and analyze blockchain transactions.
        You have access to the following transaction data: ${JSON.stringify(contextData)}
        
        When responding to queries:
        1. Always base your answers on the provided transaction data
        2. If you can't find specific information in the data, mention that limitation
        3. Present any relevant transaction IDs, amounts, timestamps, or anomaly scores when appropriate
        4. Be concise but thorough in your answers
      `;

      // Call OpenAI API
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${openAiApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: query }
          ],
          temperature: 0.3,
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        // If it's a quota error, we'll handle it in the catch block
        if (data.error?.type === 'insufficient_quota') {
          throw new Error('OpenAI quota exceeded');
        }
        console.error('OpenAI API error:', data);
        throw new Error(`OpenAI API error: ${data.error?.message || 'Unknown error'}`);
      }

      // Return the AI response
      return new Response(
        JSON.stringify({
          result: data.choices[0].message.content,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    } catch (openAiError) {
      console.error('OpenAI API error:', openAiError);
      
      // If the error is quota-related, provide a fallback response
      if (openAiError.message.includes('quota') || openAiError.message.includes('insufficient_quota')) {
        // Simple fallback logic to answer common queries about the transaction data
        let fallbackResponse = '';
        
        const lowerQuery = query.toLowerCase();
        if (lowerQuery.includes('highest anomaly') || lowerQuery.includes('most suspicious')) {
          // Find transaction with highest anomaly score
          const sorted = [...contextData].sort((a, b) => b.anomalyScore - a.anomalyScore);
          fallbackResponse = `Based on the data, transaction ${sorted[0].id} has the highest anomaly score of ${sorted[0].anomalyScore}.`;
        } 
        else if (lowerQuery.includes('lowest anomaly') || lowerQuery.includes('least suspicious') || lowerQuery.includes('lowest risk')) {
          // Find transaction with lowest anomaly score
          const sorted = [...contextData].sort((a, b) => a.anomalyScore - b.anomalyScore);
          fallbackResponse = `Based on the data, transaction ${sorted[0].id} has the lowest anomaly score of ${sorted[0].anomalyScore}, making it the lowest risk transaction.`;
        } 
        else if (lowerQuery.includes('largest') || lowerQuery.includes('biggest') || lowerQuery.includes('highest amount')) {
          // Find transaction with highest amount
          const sorted = [...contextData].sort((a, b) => b.amount - a.amount);
          fallbackResponse = `The largest transaction is ${sorted[0].id} with an amount of ${sorted[0].amount}.`;
        } 
        else {
          // Default fallback for other queries
          fallbackResponse = `[AI Quota Exceeded - Fallback Response] I can provide a basic analysis. The data shows ${contextData.length} transactions with anomaly scores ranging from ${Math.min(...contextData.map(tx => tx.anomalyScore))} to ${Math.max(...contextData.map(tx => tx.anomalyScore))}. Transaction amounts range from ${Math.min(...contextData.map(tx => tx.amount))} to ${Math.max(...contextData.map(tx => tx.amount))}.`;
        }
        
        return new Response(
          JSON.stringify({
            result: fallbackResponse,
          }),
          {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      } else {
        // Re-throw if it's not a quota error
        throw openAiError;
      }
    }
  } catch (error) {
    console.error('Error in smart-search function:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
