
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import "https://deno.land/x/xhr@0.1.0/mod.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const openAiApiKey = Deno.env.get('OPENAI_API_KEY')
    if (!openAiApiKey) {
      throw new Error('OpenAI API key not configured')
    }

    const { features } = await req.json()
    
    // Create the prompt for GPT analysis
    const prompt = `You are a fraud detection assistant. Based on these features, estimate a risk score (0 = safe, 1 = fraud) and explain why.

Feature 1: ${features.feature_1}
Feature 2: ${features.feature_2}
Feature 3: ${features.feature_3}
Feature 4: ${features.feature_4}
Feature 5: ${features.feature_5}

Return in this format:
Risk Score: {score}
Explanation: {detailed explanation}`

    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: 'You are a fraud detection AI assistant.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.2,
      }),
    })

    const data = await response.json()
    const analysis = data.choices[0].message.content

    // Parse the response
    const riskScoreMatch = analysis.match(/Risk Score:\s*([\d.]+)/)
    const explanationMatch = analysis.match(/Explanation:\s*(.+)/)

    const riskScore = riskScoreMatch ? parseFloat(riskScoreMatch[1]) : null
    const explanation = explanationMatch ? explanationMatch[1].trim() : null

    return new Response(
      JSON.stringify({ riskScore, explanation }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
